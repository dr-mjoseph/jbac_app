
var moment = require('moment');
var http = require("https");
var fs = require('fs');
process.env.SECRET_KEY = "thisismysecretkey";
var appmdl = require('../models/mainModel');
// var AWS = require('aws-sdk');
var awsS3 = 'config/aws.config.json';
var request = require('request'); //for otp
var unirest = require('unirest'); //for whtsapp 

var masterVldtr = require('../validators/mstrVldt');
// const schedule = require('node-schedule');

const crypto = require('crypto');
const algorithm = 'aes-256-cbc'; //Using AES encryption
const key = crypto.randomBytes(32);
const iv = crypto.randomBytes(16);


//single startfffffffff
exports.getdashotpCtrl = function (req, res) {
  req.checkBody(masterVldtr.loginvalidations.body);
  req.getValidationResult(req.body).then(function (result) {
    if (!result.isEmpty()) {

      res.send({ "status": 601, "message": 'Invalid parameters send', "data": [], "errors": util.inspect(result.array()[0].msg_tx) });
    } else {
      var data = req.body;
      appmdl.getdashotpMdl(data, function (err, results) {
        if (err) {
          res.send({ "status": 500, "msg": "Server Error" });
          return;
        }
        if (results && results.length > 0) {

          var loginotp = Math.floor(1001 + Math.random() * 9000);

          var message = "Siri Homeopathy Dashboard " + loginotp + ' is the OTP to complete your login. It is valid for 5 minutes. Please do not share with anyone. Team Amaravathi.';
          // Whatsapp notification start

          var req = unirest("POST", "https://live-server-6023.wati.io/api/v1/sendTemplateMessages");

          req.headers({
            "postman-token": "1bd5d6f3-15e6-ffd8-4f3a-39fd50d26819",
            "cache-control": "no-cache",
            "content-type": "application/json",
            "authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiIxOGNhMzBkNC1kOTJjLTRmMWEtYmQxMi0wYjQ2MTA1ZWFiYjkiLCJ1bmlxdWVfbmFtZSI6ImluZm9AYW1hcmF2YXRoaXNvZnR3YXJlLmNvbSIsIm5hbWVpZCI6ImluZm9AYW1hcmF2YXRoaXNvZnR3YXJlLmNvbSIsImVtYWlsIjoiaW5mb0BhbWFyYXZhdGhpc29mdHdhcmUuY29tIiwiYXV0aF90aW1lIjoiMDIvMjgvMjAyNCAwNDo0MjoxNCIsImRiX25hbWUiOiI2MDIzIiwiaHR0cDovL3NjaGVtYXMubWljcm9zb2Z0LmNvbS93cy8yMDA4LzA2L2lkZW50aXR5L2NsYWltcy9yb2xlIjpbIkJST0FEQ0FTVF9NQU5BR0VSIiwiVEVNUExBVEVfTUFOQUdFUiIsIkNPTlRBQ1RfTUFOQUdFUiIsIk9QRVJBVE9SIiwiREVWRUxPUEVSIiwiREFTSEJPQVJEX1ZJRVdFUiIsIkFVVE9NQVRJT05fTUFOQUdFUiJdLCJleHAiOjI1MzQwMjMwMDgwMCwiaXNzIjoiQ2xhcmVfQUkiLCJhdWQiOiJDbGFyZV9BSSJ9.QydIUSBAcBSu7Iz1tT_R3tjmN4kNLifrttW1YvCtAcY"
          });

          req.type("json");
          req.send({
            "template_name": "otp",
            "broadcast_name": "string",
            "receivers": [
              {
                "whatsappNumber": "91" + results[0].number,
                "customParams": [
                  {
                    "name": "name",
                    "value": results[0].name
                  },
                  {
                    "name": "shop_name",
                    "value": "Homeopathy"
                  },
                  {
                    "name": "id",
                    "value": 'loginotp'
                  }
                ]
              }
            ]
          });

          req.end(function (res) {
            if (res.error) throw new Error(res.error);
          });

          request(`http://sms.sunstechit.com/app/smsapi/index.php?key=55C4941BC46BE5&campaign=0&routeid=13&type=text&contacts=${results[0].number}&senderid=AMVTIT&msg=${message}&template_id=1207165884239050921`, function (error, response, body) {

          })
          appmdl.addOtpMdl(loginotp, results[0].number, function (err, results) {
            if (err) {
              res.send({ "status": 500, "msg": err });
              return;
            }
            res.send({ 'status': 200, 'usr_data': results });
          });
        } else {
          res.send({ "status": 202, "message": 'invalid UserName or Password' });
        }
      });
    }
  });
}



exports.getUserDataCtrl = function (req, res) {
  var phone = req.body.phone;
  var usr_pwd = req.body.usr_pwd;
  appmdl.checkUserExistMdl(phone, usr_pwd, function (err, results) {
    if (err) {
      res.send({ "status": 500, "msg": "Server Error" });
      return;
    }
    if (results && results.length > 0) {
      appmdl.getUserDataMdl(results[0].id, function (err, usrMenu) {
        if (err) {
          res.send({ "status": 500, "msg": err });
          return;
        }
        usrMenu[1].map(res => {
          res.submenu = [];
        })
        usrMenu[0].map(res => {
          var subdata = usrMenu[1].filter(obj => {
            return obj.module_id == res.id;
          })
          if (subdata.length) {
            res.submenu = subdata;
          } else {
            res.submenu = [];
          }
        })
        //
        res.send({ 'status': 200, 'data': usrMenu[0], 'usr_data': results });
      });
    } else {
      res.send({ "status": 202, "message": 'invalid UserName or Password' });
    }
  });
}
exports.deleteUsersCtrl = function (req, res) {
  var ind = req.params.ind;
  appmdl.deleteUsersMdl(ind, function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}
exports.userlogindataCtrl = function (req, res) {
  var data = req.body
  appmdl.userlogindataMdl(data, function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}
exports.updateuserlogindataCtrl = function (req, res) {
  var data = req.body
  appmdl.updateuserlogindataMdl(data, function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}
exports.addUsersCtrl = function (req, res) {
  var data = req.body;
  appmdl.getdashotpMdl(data, function (err, results) {
    if (err) {
      res.send({ "status": 500, "msg": "Server Error" });
      return;
    }
    if (results && results.length > 0) {
      res.send({ "status": 202, "message": 'User Already Exist' });
    } else {
      appmdl.addUsersMdl(data, function (err, results) {
        if (err) {
          res.send({ 'status': 500, 'data': results });
          return;
        }
        res.send({ 'status': 200, 'data': results });
      });

    }
  });
}

exports.globalGeCtrl = function (req, res) {
  var tablename = req.params.tablename;
  appmdl.globalGetMdl(tablename, function (err, results) {

    //encrypt start
    var cipher = crypto.createCipher('aes-256-cbc', '123456');
    var encrypted = Buffer.concat([cipher.update(new Buffer(JSON.stringify(results), "utf8")), cipher.final()]);
    //encrypt end
    //decrypt start
    var decipher = crypto.createDecipher("aes-256-cbc", '123456');
    var decrypted = Buffer.concat([decipher.update(encrypted), decipher.final()]);
    var decrypted_result = JSON.parse(decrypted.toString());
    //decrypt end

    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}


exports.getUserPermissionsCtrl = function (req, res) {
  appmdl.getUserPermissionsMdl(function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}
exports.getModulesCtrl = function (req, res) {
  var id = req.params.id
  appmdl.getModulesMdl(id, function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }
    var sub = results[1].filter(resp => {
      return !results[2].find(obj => {
        return resp.id == obj.sub_module_id
      })
    })

    var module = results[0].filter(resp => {
      return sub.find(obj => {
        return resp.id == obj.module_id
      })
    })
    module.map(res => {
      res.sub = sub.filter(pogo => {
        return pogo.module_id == res.id;
      })
    })
    res.send({ 'status': 200, 'data': [module, sub], 'permissions': results[3] });
  });
}
exports.getUserDatapassCtrl = function (req, res) {
  var phone = req.body.phone;
  var usr_pwd = req.body.usr_pwd;
  appmdl.checkUserpassExistMdl(phone, usr_pwd, function (err, results) {
    if (err) {
      res.send({ "status": 500, "msg": "Server Error" });
      return;
    }
    ////console.log(results)
    if (results && results.length > 0) {
      // appmdl.getUserDatapassCtrlMdl(results[0].id, function (err, usrMenu) {
      //   if (err) {
      //     res.send({ "status": 500, "msg": err });
      //     return;
      //   }
      //   res.send({ 'status': 200, 'data': usrMenu, 'usr_data': results });
      // });
      appmdl.getUserDatapassCtrlMdl(results[0].id, function (err, usrMenu) {
        console.log(usrMenu, 860)
        if (err) {
          res.send({ "status": 500, "msg": err });
          return;
        }
        usrMenu[1].map(res => {
          res.submenu = [];
        })
        usrMenu[0].map(res => {
          var subdata = usrMenu[1].filter(obj => {
            return obj.module_id == res.id;
          })
          if (subdata.length) {
            res.submenu = subdata;
          } else {
            res.submenu = [];
          }
        })
        res.send({ 'status': 200, 'data': usrMenu[0], 'usr_data': results });
      });
    } else {
      res.send({ "status": 202, "message": 'invalid UserName or Password' });
    }
  });
}
exports.submitpermissionsCtrl = function (req, res) {
  var data = req.body;
  appmdl.submitpermissionsMdl(data, function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}
exports.deletePermissionsCtrl = function (req, res) {
  var data = req.body
  appmdl.deletePermissionsMdl(data, function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}

exports.getmodulelistdetailsCtrl = function (req, res) {
  var usr_id = req.params.usr_id;
  appmdl.getmodulelistdetailsMdl(usr_id, function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }

    res.send({ 'status': 200, 'data': results });


  });
}

exports.userpermissiondatactrl = function (req, res) {
  appmdl.userpermissiondatactrlmd1(function (err, results) {
    if (err) {
      res.send(500, "Server Error");
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}
exports.getemployeelistdataCtrl = function (req, res) {
  appmdl.getemployeelistdataMdl(function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }

    res.send({ 'status': 200, 'data': results });


  });
}

exports.postusermenulistCtrl = function (req, res) {
  var dataarr = req.body;
  var date = moment().utcOffset("+05:30").format("YYYY-MM-DD HH:mm:ss");

  var module_id = dataarr[0].module_id;
  var user_id = dataarr[0].user_id;
  dataarr = dataarr.map(obj => {
    return [obj.user_id, obj.module_id, obj.id]
  })
  appmdl.postusermenulistMdl(dataarr, module_id, user_id, function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }

    res.send({ 'status': 200, 'data': results });


  });
}

exports.updateprofileCtrl = function (req, res) {
  var data = req.body;

  if (data.imageupdatestatus == true) {
    var reviewImgArr1 = data.image_array;
    var imageupload1 = '';
    var array = reviewImgArr1[0].reviewimg1.split(',');
    var datetimestamp = Date.now();
    var random_number = Math.floor(100000 + Math.random() * 900000);
    var unicnumber = random_number + '' + datetimestamp;
    var base64Data = array[1];
    var filetype = reviewImgArr1[0].filetype;
    fs.writeFile("../public_html/uploads/gallery/" + unicnumber + "." + filetype, base64Data, 'base64', function (err) { });
    var imglink = "http://texturespace.in/uploads/gallery/" + unicnumber + '.' + filetype;

  } else {
    var imglink = data.imageurl;
  }
  appmdl.updateprofileMdl(data, imglink, function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }
    res.send({ 'status': 200, 'data': results });

  });
}


// /////////////////////////////////////////////////////////////////////////////////////Analysis
exports.getweekdatawiseCtrl = function (req, res) {
  appmdl.getweekdatawiseMdl(function (err, results) {
    if (err) {
      res.send(500, "Server Error");
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}

exports.getusersanalysisCtrl = function (req, res) {
  appmdl.getusersanalysisMdl(function (err, results) {
    if (err) {
      res.send(500, "Server Error");
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}
exports.toatlcntsordersCtrl = function (req, res) {
  appmdl.toatlcntsordersMdl(function (err, results) {
    if (err) {
      res.send(500, "Server Error");
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}
// exports.totalcountsCtrl = function (req, res) {
//   appmdl.totalcountsMdl(function (err, results) {
//     if (err) {
//       res.send(500, "Server Error");
//       return;
//     }
//     res.send({ 'status': 200, 'data': results });
//   });
// }
exports.getdatewiseAnalysisCtrl = function (req, res) {
  appmdl.getdatewiseAnalysisMdl(function (err, results) {
    if (err) {
      res.send(500, "Server Error");
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}
exports.gettotalappointmentdataCtrl = function (req, res) {
  appmdl.gettotalappointmentdataMdl(function (err, results) {
    if (err) {
      res.send(500, "Server Error");
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}
// exports.topfivecustomersCtrl = function (req, res) {
//   appmdl.topfivecustomersMdl(function (err, results) {
//     if (err) {
//       res.send(500, "Server Error");
//       return;
//     }
//     res.send({ 'status': 200, 'data': results });
//   });
// }
// exports.topfiveItemsCtrl = function (req, res) {
//   appmdl.topfiveItemsMdl(function (err, results) {
//     if (err) {
//       res.send(500, "Server Error");
//       return;
//     }
//     res.send({ 'status': 200, 'data': results });
//   });
// }

// ///////////////////////////////////////////////////// analysis End 

singlevendornotifications = function (device, msgtext, seckey, appid, android_channel_id, sound, small_icon, titleHeading) {
  var restKey = '';
  var respon;
  var appID = '';
  var message = {
    "android_visibility": 1,
    // "android_sound": sound,
    // "sound": sound,
    app_id: appid,
    contents: { "en": msgtext },
    "headings": {
      "en": titleHeading
    },
    // "android_channel_id": android_channel_id,
    include_player_ids: device,
    "priority": 10,
    "playSound": true,
    "small_icon": small_icon
  };
  var headers = {
    "Content-Type": "application/json;",
    "Authorization": "Basic " + seckey
  };
  var options = {
    host: "onesignal.com",
    port: 443,
    path: "/api/v1/notifications",
    method: "POST",
    headers: headers
  };
  var https = require('https');
  var req = https.request(options, function (res) {
    res.on('data', function (data) {
      respon = data;
    });
  });
  req.on('error', function (e) {
  });
  req.write(JSON.stringify(message));
  req.end();
};
exports.getExpandDataCtrl = function (req, res) {
  appmdl.getExpandDataMdl(function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}
exports.addExpandCtrl = function (req, res) {
  var data = req.body;
  appmdl.addExpandMdl(data, function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}
exports.getAccountCtrl = function (req, res) {
  appmdl.getAccountMdl(function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}

exports.datewiseExpandCtrl = function (req, res) {
  var ind = req.params.ind;
  appmdl.datewiseExpandMdl(ind, function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}
exports.getEnquiryCtrl = function (req, res) {
  appmdl.getEnquiryMdl(function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}
exports.addEnquiryCtrl = function (req, res) {
  var data = req.body;
  appmdl.addEnquiryMdl(data, function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}
exports.deleteEnquiryCtrl = function (req, res) {
  var id = req.params.id
  appmdl.deleteEnquiryMdl(id, function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}
// // mis reports end

exports.Add_type = function (req, res) {
  var data = req.body;
  appmdl.Add_type(data, function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}

exports.getroomtype = function (req, res) {
  appmdl.getroomtype(function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}

exports.updateroomtype = function (req, res) {
  var data = req.body
  appmdl.updateroomtype(data, function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}

exports.deleteroomtype = function (req, res) {
  var data = req.body
  appmdl.deleteroomtype(data, function (err, results) {
    if (err) {
      res.send(500, "Server Error");
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}

exports.Add_rooms = function (req, res) {
  var data = req.body;
  appmdl.Add_rooms(data, function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}
exports.getrooms = function (req, res) {
  appmdl.getrooms(function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}

exports.editrooms = function (req, res) {
  var data = req.body
  appmdl.editrooms(data, function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}

exports.deleterooms = function (req, res) {
  var data = req.body
  appmdl.deleterooms(data, function (err, results) {
    if (err) {
      res.send(500, "Server Error");
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}

exports.Add_insurance = function (req, res) {
  var data = req.body;
  appmdl.Add_insurance(data, function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}

exports.getinsurance = function (req, res) {
  appmdl.getinsurance(function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
};



exports.editinsurance = function (req, res) {
  var data = req.body
  appmdl.editinsurance(data, function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}

exports.deleteinsurance = function (req, res) {
  var data = req.body
  appmdl.deleteinsurance(data, function (err, results) {
    if (err) {
      res.send(500, "Server Error");
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}
exports.gethospitalroomsctrl = function (req, res) {
  appmdl.gethospitalroomsmdl(function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}
exports.getpatientsdata = function (req, res) {
  appmdl.getpatientsdata(function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}



exports.admitpatient_room = function (req, res) {
  var data = req.body;
  appmdl.checkTodayPatientCounts(data, function (err, results) {
    if (results) {
      var sequenceNumber;
      this.sequenceNumber = parseInt(results[0].new_patients_count)
      this.sequenceNumber++;

      const currentDate = new Date();
      const year = currentDate.getFullYear().toString().substr(-2);
      const month = ('0' + (currentDate.getMonth() + 1)).slice(-2);
      const day = ('0' + currentDate.getDate()).slice(-2);

      const id = `IP${year}${month}${day}${('000' + this.sequenceNumber).slice(-3)}`;

      appmdl.admitpatient_room(id, data, function (err, results) {
        if (err) {
          res.send({ "status": 500, "msg": err });
          return;
        }
        res.send({ 'status': 200, 'data': results });
      });
    }
    else {
      res.send({ 'status': 500 });
    }
  });
}


// *************************************************** Add patient Start ********************************************************************

exports.addpatientctrl = function (req, res) {
  if (req.body.patient_type == 'NEW' && req.body.old_uhid_no == null) {
    appmdl.checkTodayPatientCount(req.body, function (err, results) {
      if (results) {
        var sequenceNumber;
        this.sequenceNumber = parseInt(results[0].new_patients_count)
        this.sequenceNumber++;

        const currentDate = new Date();
        const year = currentDate.getFullYear().toString().substr(-2);
        const month = ('0' + (currentDate.getMonth() + 1)).slice(-2);
        const day = ('0' + currentDate.getDate()).slice(-2);

        const id = `OP${year}${month}${day}${('00' + this.sequenceNumber).slice(-3)}`;

        appmdl.addpatientmdl(id, req.body, function (err, results) {
          if (err) {
            res.send({ "status": 500, "msg": err });
            return;
          }
          res.send({ 'status': 200, 'data': results });
        });
      }
      else {
        res.send({ 'status': 500 });
      }
    });
  }
  else {
    var id = req.body.old_uhid_no
    appmdl.addpatientmdl(id, req.body, function (err, results) {
      if (err) {
        res.send({ "status": 500, "msg": err });
        return;
      }
      res.send({ 'status': 200, 'data': results });
    });
  }
}

exports.getpatientsctrl = function (req, res) {
  appmdl.getpatientsmdl(req.body, function (err, results) {
    if (err) {
      res.send({ "status": 500, "msg": err });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}

exports.EditPatientctrl = function (req, res) {
  appmdl.EditPatientmdl(req.body, function (err, results) {
    if (err) {
      res.send({ "status": 500, "msg": err });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}



exports.getDataAllpatientsCtrl = function (req, res) {
  appmdl.getDataAllpatientsmmdl(req.body, function (err, results) {
    if (err) {
      res.send({ "status": 500, "msg": err });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}



exports.checkCardRnwlforUhoCtrl = function (req, res) {
  appmdl.checkCardRnwlforUhommdl(req.body, function (err, results) {
    if (err) {
      res.send({ "status": 500, "msg": err });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}

exports.getbookingsrchdatactrl = async (req, res) => {

  appmdl.getbookingsrchdatamdl(req.body, function (err, results) {
    if (err) {
      res.send({ "status": 500, "msg": "Server Error" });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });

}


exports.getbookingdatactrl = function (req, res) {

  appmdl.getbookingdatamdl(function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}




exports.getDoctorsDataCtrl = function (req, res) {
  appmdl.getDoctorsDatammdl(req.body, function (err, results) {
    if (err) {
      res.send({ "status": 500, "msg": err });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}

exports.Add_doctorctrl = function (req, res) {
  appmdl.Add_doctormdl(req.body, function (err, results) {
    if (err) {
      res.send({ "status": 500, "msg": err });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}

exports.getdepartmentctrl = function (req, res) {
  appmdl.getdepartmentmdl(req.body, function (err, results) {
    if (err) {
      res.send({ status: 500, msg: err });
      return;
    }
    res.send({ status: 200, data: results });
  });
};

exports.gettimingsctrl = function (req, res) {
  appmdl.gettimingsmdl(req.body, function (err, results) {
    if (err) {
      res.send({ status: 500, msg: err });
      return;
    }
    res.send({ status: 200, data: results });
  });
};

exports.addNewdepartmentCtrl = function (req, res) {
  appmdl.addNewdepartmentmdl(req.body, function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}


exports.addNewtimingsCtrl = function (req, res) {
  appmdl.addNewtimingsmdl(req.body, function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}


// *************************************************** Add patient Start end ******************************************************************** 

//prasad 02052024//
exports.getappoinmentreportformCtrl = function (req, res) {
  appmdl.getappoinmentreportformMdl(function (err, results) {
    if (err) {
      console.log(err);
      res.send(500, "Server Error");
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}
exports.getfromdatetodatectrl = function (req, res) {
  var u_id = req.params.u_id;
  var fromdate = req.params.fromdate;
  var toDate = req.params.toDate;
  var location = req.params.location;
  var appointment=req.params.appointment;
  appmdl.getfromdatetodateMdl(fromdate, toDate, u_id, location,appointment, function (err, results) {
    if (err) {
      res.send(500, "Server Error");
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}

exports.getlocationdropdownCtrl = function (req, res) {
  appmdl.getlocationdropdownpageMdl(function (err, results) {
    if (err) {
      console.log(err);
      res.send(500, "Server Error");
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}
exports.getpatientdropdowCtrl = function (req, res) {
  appmdl.getpatientdropdowMdl(function (err, results) {
    if (err) {
      console.log("err " + err);
      res.send(500, "Server Error");
      return;
    }
    res.send({ "status": 200, "data": results });
  });
}
exports.getphonedropdowCtrl = function (req, res) {
  appmdl.getphonedropdowMdl(function (err, results) {
    if (err) {
      console.log("err " + err);
      res.send(500, "Server Error");
      return;
    }
    res.send({ "status": 200, "data": results });
  });
}
exports.getPatient1Ctrl = function (req, res) {
  var data = req.body
  appmdl.getPatient1Mdl(data, function (err, results) {
    if (err) {
      console.log("err " + err);
      res.send(500, "Server Error");
      return;
    }
    res.send({ "status": 200, "data": results });
  });
}
exports.updatecontactdetailsformCtrl = function (req, res) {
  var data = req.body;
  appmdl.updatecontactdetailsformpageMdl(data, function (err, results) {
    if (err) {
      res.send({ "status": 500, "msg": "Server Error" });
      return;
    }
    res.send({ "status": 200, "msg": 'Category Updated Successfully' });
  });
}
exports.deletecontactformCtrl = function (req, res) {
  var id = req.params.id;
  appmdl.deletecontactformMdl(id, function (err, cRes) {
    if (err) {
      res.send({ "status": 500, "msg": "Server Error" });
      return;
    }
    res.send({ "status": 200, "data": 'Deleted Successfully' });
  });
}
exports.getcontactreportformformCtrl = function (req, res) {
  appmdl.getcontactreportformformMdl(function (err, results) {
    if (err) {
      res.send(500, "Server Error");
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}
exports.getlocationdropdownformpageCtrl = function (req, res) {
  appmdl.getlocationdropdownformpagewiseMdl(function (err, results) {
    if (err) {
      res.send(500, "Server Error");
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}
exports.updatefromtotimedetailsCtrl = function (req, res) {
  var data = req.body;
  appmdl.updatefromtotimedetailsformMdl(data, function (err, results) {
    if (err) {
      res.send({ "status": 500, "msg": "Server Error" });
      return;
    }
    res.send({ "status": 200, "msg": 'Category Updated Successfully' });
  });
}
exports.gettimetotalcheckCtrl = function (req, res) {
  appmdl.gettimetotalcheckdataMdl(function (err, results) {
    if (err) {
      res.send(500, "Server Error");
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}
exports.checktimectrl = function (req, res) {
  var fromtime = req.body;
  // var totime = req.params.totime;
  appmdl.checktimepagemdl(fromtime, function (err, results) {
    if (err) {
      res.send(500, "Server Error");
      return;
    }
    res.send({ 'status': 200, 'data': results, "msg": "submited" });
  });
}
exports.postappointmentsctrl = function (req, res) {
  var data = req.body;
  appmdl.postappointmentsformMdl(data, function (err, results) {
    if (err) {
      res.send(500, "Server Error");
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}
exports.deletetimeslotspageCtrl = function (req, res) {
  var id = req.params.id;
  appmdl.deletetimeslotspageformMdl(id, function (err, cRes) {
    if (err) {
      res.send({ "status": 500, "msg": "Server Error" });
      return;
    }
    res.send({ "status": 200, "data": 'Deleted Successfully' });
  });
}
exports.getlocationdropdownCtrl = function (req, res) {
  appmdl.getlocationdropdownpageMdl(function (err, results) {
    if (err) {
      console.log(err);
      res.send(500, "Server Error");
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}
exports.getmonthreportdatactrl = function (req, res) {
  var data = req.body;
  console.log(data);
  appmdl.getmonthreportdatamdl(data, function (err, results) {
    if (err) {
      console.log("err " + err);
      res.send(500, "Server Error");
      return;
    }
    res.send({ "status": 200, "data": results });
  });
}
exports.getfrommonthCtrl = function (req, res) {
  var u_id = req.params.u_id;
  var months = req.params.months;
  appmdl.getfrommonthMdl(months, u_id, function (err, results) {
    if (err) {
      res.send(500, "Server Error");
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}
exports.deletemonthadatCtrl = function (req, res) {
  var id = req.params.id;
  appmdl.deletemonthadatpageMdl(id, function (err, cRes) {
    if (err) {
      res.send({ "status": 500, "msg": "Server Error" });
      return;
    }
    res.send({ "status": 200, "data": 'Deleted Successfully' });
  });
}
exports.getmonthwiseformCtrl = function (req, res) {
  // var usr_id = req.params.usr_id;
  appmdl.getmonthwiseformpageMdl(function (err, results) {
    if (err) {
      res.send(500, "Server Error");
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}
exports.submitofflinedatactrl = function (req, res) {
  var data = req.body;
  console.log(data, "6278hii")
  appmdl.getLastopId(function (err, lastInvId) {
    if (err) {
      console.log("err " + err);
      res.send(500, "Server Error");
      return;
    }
    if (lastInvId[0]) {
      var op_idi = lastInvId[0].op_idi;
    } else {
      var op_idi = 0;
    }
    var op_idi = op_idi + 1;
    var op_number = "OP" + op_idi;
    appmdl.submitofflinedatapageMdl(data, op_idi, op_number, function (err, results) {
      if (err) {
        res.send(500, "Server Error");
        return;
      }
      res.send({ 'status': 200, 'data': results });
    });
  });
}
exports.getlocationdropofflineformCtrl = function (req, res) {
  appmdl.getlocationdropofflineformpageMdl(function (err, results) {
    if (err) {
      res.send(500, "Server Error");
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}
exports.postsubmitgalleryCtrl = function (req, res) {
  var data = req.body;
  var UploadImage = data.UploadImage;
  var imageupload = '';
  var array = UploadImage[0].reviewimg.split(',');
  var datetimestamp = Date.now();
  var random_number = Math.floor(100000 + Math.random() * 900000);
  var unicnumber = random_number + '' + datetimestamp;
  var base64Data = array[1];
  var filetype = UploadImage[0].filetype;
  fs.writeFile("../public_html/app_images/" + unicnumber + "." + filetype, base64Data, 'base64', function (err) {
  });

  imageupload = "https://srisanthienthospital.com/app_images/" + unicnumber + '.' + filetype;
  appmdl.postsubmitgallerypageMdl(data, imageupload, function (err, results) {
    if (err) {

      res.send(500, "Server Error");
      return;
    }

    res.send({ 'status': 200, 'data': results });
  });
}
exports.getgallerydataCtrl = function (req, res) {
  appmdl.getgallerydataMdl(function (err, results) {
    if (err) {
      res.send(500, "Server Error");
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}
exports.modelgallaryimageeditctrl = function (req, res) {
  var data = req.body;
  console.log(data);
  var reviewImgArr = data.reviewimg1;
  console.log(reviewImgArr);
  var array1 = reviewImgArr.split(',');
  var base64Data = array1[1];
  var datetimestamp = Date.now();
  var random_number = Math.floor(100000 + Math.random() * 900000);
  var unicnumber = random_number + '' + datetimestamp;
  var filetype = data.filetype;
  fs.writeFile("../public_html/app_images/" + unicnumber + '.' + 'filetype', base64Data, 'base64', function (err) {
  });
  imageupload = "https://srisanthienthospital.com/app_images/" + unicnumber + '.' + 'filetype';

  appmdl.modelgallaryimageeditmdl(data, imageupload, function (err, results) {
    if (err) {
      res.send(500, "Server Error");
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}
exports.deleteimageCtrl = function (req, res) {
  var icons = req.params;
  console.log(icons);
  appmdl.deleteimageMdl(icons, function (err, results) {
    if (err) {
      res.send({ "status": 500, "msg": 'Data Submitted Failed' });
      return;
    }
    res.send({ "status": 200, "data": results, "msg": "submited" });
  });
}


exports.checkoutpatient_roomctrl = function (req, res) {
  appmdl.checkoutpatient_roommdl(req.body, function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}

exports.checkoutpatientsubmitctrl = function (req, res) {
  appmdl.checkoutpatientsubmitmdl(req.body, function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}
exports.availableroomtypectrl = function (req, res) {
  appmdl.availableroomtypemdl(req.body, function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}

exports.checkinreports = function (req, res) {
  appmdl.checkinreports(req.body, function (err, results) {
    if (err) {
      res.send({ "status": 500, "msg": err });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}
exports.checkoutreports = function (req, res) {
  appmdl.checkoutreports(req.body, function (err, results) {
    if (err) {
      res.send({ "status": 500, "msg": err });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}





// *************************************************** Diagnostic Start  ********************************************************************

exports.adddiagnoTestCtrl = function (req, res) {
  appmdl.adddiagnoTestmmdl(req.body, function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}



exports.getdiagnosticTestsCtrl = function (req, res) {
  appmdl.getdiagnosticTestsmmdl(req.body, function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}


exports.editdiagnoTestCtrl = function (req, res) {
  appmdl.editdiagnoTestmmdl(req.body, function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}



exports.dltdiagnoTestCtrl = function (req, res) {
  appmdl.dltdiagnoTestmmdl(req.body, function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}




exports.addpatientDetailsTestsCtrl = function (req, res) {
  appmdl.adddiagnoptntDtsmmdl(req.body, function (err, results) {
    if (results) {
      appmdl.adddiagnoptntTstdtsmmdl(results.insertId, req.body, function (err, results) {
        if (err) {
          res.send({ 'status': 500, 'data': results });
          return;
        }
        res.send({ 'status': 200, 'data': results });
      });
    }
    else {
      res.send({ 'status': 500, 'data': results });
    }
  });
}




exports.getpatientsDetailsTestsCtrl = function (req, res) {
  appmdl.getpatientsDetailsTestsmmdl(req.body, function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}



exports.getpatientDiagnosticTestsCtrl = function (req, res) {
  appmdl.getpatientDiagnosticTestsmmdl(req.body, function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}


// *************************************************** Diagnostic Start end   ********************************************************************




// ************************************************************ labs  start ******************************************************************************


exports.add_labtestctrl = function (req, res) {
  appmdl.add_labtestmdl(req.body, function (err, results) {
    if (results) {
      var array = req.body.data2
      var count = 0
      for (let i = 0; i < array.length; i++) {
        appmdl.postLabFieldsmmdl(results.insertId, req.body, array[i], function (err, results) {
        });
        count++
        if (array.length == count) {
          res.send({ 'status': 200 });
        }
      }
    } else {
      res.send({ 'status': 500 });
    }
  });
}


exports.get_labtestctrl = function (req, res) {
  appmdl.get_labtestmdl(req.body, function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}

exports.delete_labtestctrl = function (req, res) {
  appmdl.delete_labtestmdl(req.body, function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}

exports.editlabDetailsCtrl = function (req, res) {
  appmdl.editlabDetailsmdl(req.body, function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}


exports.getlabtestFieldsCtrl = function (req, res) {
  appmdl.getlabtestFieldsmmdl(req.body, function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}

exports.addassign_medicaltestsctrl = function (req, res) {
  appmdl.addassign_medicaltestsmdl(req.body, function (err, results) {
    if (results) {
      appmdl.assignedmedicltests(results.insertId, req.body, function (err, results) {
        if (results) {
          res.send({ 'status': 200 });
        } else {
          res.send({ 'status': 500 });
        }
      });
    } else {
      res.send({ 'status': 500 });
    }
  });
}


exports.getlabreportsnum = function (req, res) {
  appmdl.getlabreportsnum(req.body, function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}


exports.getlabtestnames = function (req, res) {
  appmdl.getlabtestnames(req.body, function (err, results) {
    if (results.length) {
      res.send({ 'status': 200, 'data': results });
    } else {
      res.send({ 'status': 500 });
    }
  });
}


exports.PostTestsDoneDataCtrl = function (req, res) {
  var TotalTests = req.body.completeTest
  TotalTests = JSON.parse(TotalTests)
  var count = 0;
  for (let i = 0; i < TotalTests.length; i++) {
    appmdl.PostTestsDoneDataMmdl(req.body.update_id, req.body.patient_details, TotalTests[i], function (err, results) {

    });
    count++
  }
  if (count == TotalTests.length) {
    appmdl.setLabTestDonemmdl(req.body.update_id, function (err, results) {
      if (err) {
        res.send({ 'status': 500, 'data': results });
        return;
      }
      res.send({ 'status': 200, 'data': results });
    });
  }
}


exports.getmedicalreportsctrl = function (req, res) {
  appmdl.getmedicalreportsmdl(req.body, function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}


exports.getparticularlabdetialsctrl = function (req, res) {
  appmdl.getparticularlabdetialsmdl(req.body, function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}


exports.getLabResultsEachCtrl = function (req, res) {
  appmdl.getLabResultsEachmmdl(req.body, function (err, results) {
    if (results.length) {
      res.send({ 'status': 200, 'data': results });
    } else {
      res.send({ 'status': 500 });
    }
  });
}

exports.editlabdatactrl = function (req, res) {
  appmdl.editlabdatamdl(req.body, function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}

exports.mainGetforAssignLabsctrl = function (req, res) {
  appmdl.mainGetforAssignLabsmdl(req.body, function (err, results) {
    if (err) {
      res.send({ "status": 500, "msg": err });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}

exports.getlabTestsctrl = function (req, res) {
  appmdl.getlabTestsmdl(req.body, function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}


// ************************************************************ labs  end ******************************************




//04052024//
exports.pharmaitemsaddCtrl = function (req, res) {
  var data = req.body
  appmdl.pharmaitemsaddMdl(data, function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}
exports.getmedicinenameCtrl = function (req, res) {
  appmdl.getmedicinenameMdl(function (err, results) {
    if (err) {
      res.send(500, "Server Error");
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}
exports.supplieradddataCtrl = function (req, res) {
  var data = req.body
  appmdl.supplieradddataMdl(data, function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}
exports.getsupplierdataCtrl = function (req, res) {
  appmdl.getsupplierdataMdl(function (err, results) {
    if (err) {
      res.send(500, "Server Error");
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}
exports.getmedicinetypesCtrl = function (req, res) {
  appmdl.getmedicinetypesMdl(function (err, results) {
    if (err) {
      res.send(500, "Server Error");
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}
exports.todaycheckindata = function (req, res) {
  appmdl.todaycheckindata(function (err, results) {
    if (err) {
      res.send(500, "Server Error");
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}

exports.todaycheckoutdata = function (req, res) {
  appmdl.todaycheckoutdata(function (err, results) {
    if (err) {
      res.send(500, "Server Error");
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}

exports.gettodayaccountCtrl = function (req, res) {
  var data = req.body
  appmdl.gettodayaccountmdl(data, function (err, results) {
    if (err) {
      res.send(500, "Server Error");
      return;
    }
    res.send({ "status": 200, "data": results });
  });
}

exports.getDatewiseamountCtrl = function (req, res) {
  var data = req.body
  appmdl.getDatewiseamountmdl(data, function (err, results) {
    if (err) {
      res.send(500, "Server Error");
      return;
    }
    res.send({ "status": 200, "data": results });
  });
}
//***********************************op-patients(insurance)*************************/

exports.addInsuranceCtrl = function (req, res) {
  var data = req.body
  appmdl.addInsurancemdl(data, function (err, results) {
    if (err) {
      res.send(500, "Server Error");
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}
exports.getInsuranceCtrl = function (req, res) {
  appmdl.getInsurancemdl(function (err, results) {
    console.log(1659, results)
    if (err) {
      res.send(500, "Server Error");
      return;
    }
    res.send({ "status": 200, "data": results });
  });
}

exports.getPhonenumberCtrl = function (req, res) {
  appmdl.getPhonenumberMdl(function (err, results) {
    if (err) {
      res.send({ 'status': 500, 'data': results });
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}
exports.getappoinmentreportform1Ctrl = function (req, res) {
  appmdl.getappoinmentreportform1Mdl(function (err, results) {
    if (err) {
      console.log(err);
      res.send(500, "Server Error");
      return;
    }
    res.send({ 'status': 200, 'data': results });
  });
}







//prasad addedon 18-05-2024//
//watiiii
exports.getsstimeslotsDataCtrl1 = function (req, res) {
    var date = req.params.date;
    var loc = req.params.loc;
    var phno = req.params.phno;
    console.log(date,loc,phno)
    //  if (loc == "అత్తిలి") {
    //      loc = "Attili";
    // }else if(loc == "రాజమండ్రి") {
    //     loc = "Rajahmundry";
    // }else if(loc == "పాలకొల్లు")
    // {
    //     loc = "Palakollu";
    // }else if(loc == "తణుకు")
    // {
    //     loc = "Tanuku";
    // }
 appmdl.getdoctornameMdl1(date,loc, function (err, dresults) {
    if (err) {
        console.log(err)
        res.send(500, "Server Error");
        return;
    }
    appmdl.getsstimeslotsDataMdl1(date,loc, function (err, results) {
        if (err) {
            console.log(err)
            res.send(500, "Server Error");
            return;
        }
         console.log(results)
         if(results.length !=0){
             const url = 'https://live-server-6023.wati.io/api/v1/sendInteractiveListMessage?whatsappNumber='+phno;
        const options = {
          method: 'POST',
          headers: {
            'Content-Type': 'text/json',
            Authorization: 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiI0YjIxOWE5NC04OTYzLTRhOTctYTBlMS0wYWRkNjAyOTUzY2IiLCJ1bmlxdWVfbmFtZSI6ImluZm9AYW1hcmF2YXRoaXNvZnR3YXJlLmNvbSIsIm5hbWVpZCI6ImluZm9AYW1hcmF2YXRoaXNvZnR3YXJlLmNvbSIsImVtYWlsIjoiaW5mb0BhbWFyYXZhdGhpc29mdHdhcmUuY29tIiwiYXV0aF90aW1lIjoiMTAvMTQvMjAyMiAwNTo0MDoxNCIsImRiX25hbWUiOiI2MDIzIiwiaHR0cDovL3NjaGVtYXMubWljcm9zb2Z0LmNvbS93cy8yMDA4LzA2L2lkZW50aXR5L2NsYWltcy9yb2xlIjpbIlRFTVBMQVRFX01BTkFHRVIiLCJDT05UQUNUX01BTkFHRVIiLCJPUEVSQVRPUiIsIkRFVkVMT1BFUiIsIkRBU0hCT0FSRF9WSUVXRVIiLCJBVVRPTUFUSU9OX01BTkFHRVIiXSwiZXhwIjoyNTM0MDIzMDA4MDAsImlzcyI6IkNsYXJlX0FJIiwiYXVkIjoiQ2xhcmVfQUkifQ.jBUHu02jcorUilCPtTC49YEoBpr5fRLXBXDXuOESsE0'
          },
          body: JSON.stringify({
           sections: [
                      {rows: results, title: 'Menu'}
                    ],
            body:'OP Timings List',
            buttonText: 'Click Here'
          })
        };
        console.log(dresults[0].doctor_name)
        fetch(url, options)
          .then(res => res.json())
          .then(res.send({ 'status': 200, 'data': dresults[0].doctor_name}))
          .catch(err => console.error('error:' + err));
         }
        else{
            res.send({ 'status': 300})
        }
    });
 });
}






exports.ssappointmentsDataCtrl = function (req, res) {
    var std = req.body;
    if(std.wati_ind == "1")
	{
	   var dated = std.cdate;
	}else
	{
	   var tabName = std.cdate.split('-');
        var dated = tabName[2] + "-" + tabName[1] + "-" + tabName[0];
	}
	
    if(std.phone_no.length == "10")
    {
        std.phone_no = "91" + std.phone_no;
    }
    
    if(std.location == "Palakollu"){
        var temp_name = "ent_pala_eng";
        var location = "Palakollu"
    }
    else if(std.location == "Attili"){
         var temp_name = "ent_attili_eng";
         var location = "Attili"
    }
    else if(std.location == "Tanuku"){
        var temp_name = "ent_tan_eng";
        var location = "Tanuku"
    }
    else if (std.location == "అత్తిలి") {
         var temp_name = "ent_attili_telugu";
        var location = "అత్తిలి"
    }
    else if(std.location == "రాజమండ్రి") {
        var temp_name = "ent_rjy_telugu";
        var location = "రాజమండ్రి"
    }
    else if(std.location == "పాలకొల్లు")
    {
        var temp_name = "ent_palakollu_telugu";
        var location = "పాలకొల్లు"
    }
    else if(std.location == "తణుకు")
    {
      var temp_name = "ent_tanu_telugu";
      var location = "తణుకు"
    }
    else{
        var temp_name = "ent_rjy_eng";
        var location = "Rajahmundry"
    }
   
    console.log(std);
    
    if(std.wati_ind == "1")
	{
    	var tabName = std.cdate.split('-');
    	var dated = tabName[2] + "-" + tabName[1] + "-" + tabName[0];
	}else
	{
	    var dated = std.cdate;
	}
	
    appmdl.getLastopId(dated,function (err, lastInvId) {
        if (err) {
            console.log("err " + err);
            res.send(500, "Server Error");
            return;
        }
        if (lastInvId[0]) {
            var op_idi = lastInvId[0].op_idi;
        } else {
            var op_idi = 0;
        }
    	var op_idi = op_idi + 1;
        var op_number = "OP" + op_idi;
    appmdl.ssappointmentsDataMdl(std,op_idi,op_number, function (err, results) {
        if (err) {
            res.send({ 'status': 500, 'data': results });
            return;
        }
        // res.send({ 'status': 200, 'data': results });
        appmdl.getssapointmentvalueMdl(std, function (err, rresults) {
            if (err) {
                res.send({ 'status': 500 });
                return;
            }
            
            //start
            var req = unirest("POST", "https://live-server-6023.wati.io/api/v1/sendTemplateMessages");
            req.headers({
                "postman-token": "7582f32a-780b-bdb7-dc50-704bff9bd850",
                "cache-control": "no-cache",
                "content-type": "application/json",
                "authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiJlZjdjZmI1Ni01MTJlLTQxYTMtYWY5Ny03NzNkODdmNTU4Y2QiLCJ1bmlxdWVfbmFtZSI6ImluZm9AYW1hcmF2YXRoaXNvZnR3YXJlLmNvbSIsIm5hbWVpZCI6ImluZm9AYW1hcmF2YXRoaXNvZnR3YXJlLmNvbSIsImVtYWlsIjoiaW5mb0BhbWFyYXZhdGhpc29mdHdhcmUuY29tIiwiYXV0aF90aW1lIjoiMTAvMTgvMjAyMiAwMzo1NDo1OSIsImRiX25hbWUiOiI2MDIzIiwiaHR0cDovL3NjaGVtYXMubWljcm9zb2Z0LmNvbS93cy8yMDA4LzA2L2lkZW50aXR5L2NsYWltcy9yb2xlIjpbIlRFTVBMQVRFX01BTkFHRVIiLCJDT05UQUNUX01BTkFHRVIiLCJPUEVSQVRPUiIsIkRFVkVMT1BFUiIsIkRBU0hCT0FSRF9WSUVXRVIiLCJBVVRPTUFUSU9OX01BTkFHRVIiXSwiZXhwIjoyNTM0MDIzMDA4MDAsImlzcyI6IkNsYXJlX0FJIiwiYXVkIjoiQ2xhcmVfQUkifQ.TltYJiIrEhP1GpsKsUwBLdrWLrrfLGbuU1qTwn7DATY"
            });

        req.type("json");
        req.send({
            "template_name": temp_name,
            "broadcast_name": temp_name,
            "receivers": [
                {
                    "whatsappNumber": std.phone_no,
                    "customParams": [
                        {
                            "name": "name",
                            "value": std.name
                        },
                        {
                            "name": "op_number",
                            "value":  op_number
                        },
                        {
                            "name": "date",
                            "value": dated 
                        },
                        {
                            "name": "time",
                            "value": std.time 
                        },
                        {
                            "name": "hospital_location",
                            "value": location 
                        },
                        
                    ]
                }
            ]
        });

        req.end(function (res) {
           
            if (res.error) throw new Error(res.error);
        });
        //end
         res.send({ 'status': 200, 'data': rresults,'op_number':op_number });
        });
        });
    });
}































































