var sqldb = require('../../config/dbconnect');
var dbutil = require(appRoot + '/utils/dbutils');
var moment = require('moment');
// const { log } = require('forever');

//single start
exports.getdashotpMdl = function (data, callback) {
	var cntxtDtls = "in getdashotpMdl";
	var QRY_TO_EXEC = `select * from users  where d_in = '0' and number = '${data.number}' ; `
	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};

exports.addOtpMdl = function (otp, number, callback) {
	var cntxtDtls = "in addOtpMdl";
	var QRY_TO_EXEC = `update  users set otp = '${otp}'   where d_in = '0' and number = '${number}' ; `

	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};

exports.checkUserExistMdl = function (number, pwd, callback) {
	var cntxtDtls = "in checkUserExistMdl";
	var QRY_TO_EXEC = ` SELECT * from users where number ='${number}' and  otp ='${pwd}' and d_in <> 1;`;

	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};

exports.getUserDataMdl = function (user_id, callback) {
	var cntxtDtls = "in getUserDataMdl";
	var QRY_TO_EXEC = `SELECT mm.* from main_modules as mm join permissions as ps on mm.id=ps.module_id  where ps.user_id ='${user_id}' and ps.d_in <> 1 and mm.d_in=0 group by  ps.module_id    ;
	SELECT mm.* from sub_modules as mm join permissions as ps on mm.id=ps.sub_module_id  where ps.user_id ='${user_id}' and ps.d_in <> 1 and mm.d_in=0 order by module_order  ;
	`;
	// 
	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};
exports.deleteUsersMdl = function (id, callback) {
	var cntxtDtls = "in deleteUsersMdl";
	var QRY_TO_EXEC = `update  users set d_in = 1   where id  = '${id}' ; `

	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};
exports.userlogindataMdl = function (data, callback) {
	var cntxtDtls = "in userlogindataMdl";
	var QRY_TO_EXEC = `insert into user_logins (user_id, cts) values ( '${data.user_id}',  '${data.cts}' ) ; `
	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};
exports.updateuserlogindataMdl = function (data, callback) {
	var cntxtDtls = "in updateuserlogindataMdl";
	var QRY_TO_EXEC = `update  user_logins set end = '${data.end}' where  user_id =  '${data.user_id}' and cts =   '${data.cts}'  ; `
	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};
exports.addUsersMdl = function (user, callback) {
	var cntxtDtls = "in addUsersMdl";
	var QRY_TO_EXEC = ` insert into users (name, number,email) 
	values( '${user.name}', '${user.number}', '${user.email}') ;`;

	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};
exports.globalGetMdl = function (tablename, callback) {
	var cntxtDtls = "in globalGetMdl";

	var QRY_TO_EXEC = ' select * from ' + tablename + ' where d_in = 0 order by id desc;';

	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};
exports.checkUserpassExistMdl = function (number, pwd, callback) {
	var cntxtDtls = "in checkUserpassExistMdl";
	var QRY_TO_EXEC = ` SELECT * from users where number ='${number}' and  pwd ='${pwd}' and d_in <> 1;`;

	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};

exports.getUserDatapassCtrlMdl = function (user_id, callback) {
	var cntxtDtls = "in getUserDatapassCtrlMdl";
	var QRY_TO_EXEC = `SELECT mm.* from main_modules as mm join permissions as ps on mm.id=ps.module_id  where ps.user_id ='${user_id}' and ps.d_in <> 1 and mm.d_in=0 group by  ps.module_id    ;
	SELECT mm.* from sub_modules as mm join permissions as ps on mm.id=ps.sub_module_id  where ps.user_id ='${user_id}' and ps.d_in <> 1 and mm.d_in=0 order by module_order`;

	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};
exports.getUserPermissionsMdl = function (callback) {
	var cntxtDtls = "in getUserPermissionsMdl";
	var QRY_TO_EXEC = `SELECT * from users  WHERE  users.d_in = 0;`;
	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};


exports.getModulesMdl = function (id, callback) {
	var cntxtDtls = "in getModulesMdl";
	var QRY_TO_EXEC = `SELECT * from main_modules WHERE  d_in = 0; SELECT * from sub_modules  WHERE  d_in = 0; SELECT * from permissions  WHERE  d_in = 0 and user_id = '${id}' ;
	SELECT ps.*, ss.title FROM permissions as ps join sub_modules as ss on ps.sub_module_id = ss.id where ps.user_id = '${id}' and ps.d_in = 0`;
	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};

exports.submitpermissionsMdl = function (persdata, callback) {
	var cntxtDtls = "in submitpermissionsMdl";
	var QRY_TO_EXEC = '';
	persdata.permissions.map(res => {
		var sub_sq = ` insert into permissions (user_id, module_id, sub_module_id) values( '${persdata.usr_id}', '${res.main_id}', '${res.id}') ;`;
		QRY_TO_EXEC = QRY_TO_EXEC + sub_sq;
	})
	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};
exports.deletePermissionsMdl = function (data, callback) {
	var cntxtDtls = "in deletePermissionsMdl";
	var QRY_TO_EXEC = '';
	var sub_que = '';
	data.map(respo => {
		sub_que = `update  permissions set d_in = 1   where id  = '${respo.id}' ; `
		QRY_TO_EXEC = QRY_TO_EXEC + sub_que;
	})


	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};
exports.getmodulelistdetailsMdl = function (usr_id, callback) {
	var cntxtDtls = "in getmodulelistdetailsMdl";
	var QRY_TO_EXEC = `SELECT CASE
    WHEN user_id IS NOT null  THEN 'true'
    WHEN user_id IS null  THEN 'false'
    ELSE 'false'
END as check_sub_menu, user_id,sm.id,sm.module_id,m.title as module_nm,sm.path,sm.icon,sm.title,sm.id,m.icon,p.d_in,
        CASE
            WHEN user_id IS NULL THEN 0
            ELSE 1
        END AS check_sub_menu,module_order
        FROM sub_modules as sm
        JOIN main_modules as m ON sm.module_id = m.id
        left JOIN  (SELECT * from permissions WHERE user_id=${usr_id}) as p  ON p.sub_module_id=sm.id
        WHERE sm.d_in=0 and m.d_in=0 order by sm.module_id`;

	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};

exports.userpermissiondatactrlmd1 = function (callback) {
	var date = moment().utcOffset("+05:30").format("YYYY-MM-DD HH:mm:ss");
	var cntxtDtls = "in userpermissiondatactrlmd1";

	var QRY_TO_EXEC = `SELECT l.id,name,l.number, l.email, GROUP_CONCAT(DISTINCT m.title) AS module_nm, COUNT(m.title) as mcnt, GROUP_CONCAT(sm.title) AS sub_menu 
FROM permissions as p 
JOIN sub_modules AS sm ON p.sub_module_id = sm.id 
JOIN main_modules AS m ON p.module_id = m.id 
JOIN users as l ON l.id = p.user_id 
where p.d_in=0 and l.d_in=0 and m.d_in=0 
GROUP BY p.user_id ORDER BY mcnt,l.id`;

	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};

exports.getemployeelistdataMdl = function (callback) {
	var cntxtDtls = "in getemployeelistdataMdl";
	var QRY_TO_EXEC = `SSELECT * FROM users WHERE d_in=0 order by name`;
	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};

exports.postusermenulistMdl = function (data, module_id, usr_id, callback) {
	var date = moment().utcOffset("+05:30").format("YYYY-MM-DD HH:mm:ss");
	var cntxtDtls = "in postusermenulistMdl";
	var QRY_TO_EXEC2 = `DELETE FROM permissions WHERE user_id = ${usr_id};`;
	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC2, cntxtDtls, function (err, results1) {
			var QRY_TO_EXEC = `insert into permissions (user_id, module_id, sub_module_id) values ? `;

			dbutil.execinsertQuerys(sqldb.MySQLConPool, QRY_TO_EXEC, data, cntxtDtls, function (err, results) {
				callback(err, results);
				return;
			});
		});
	}
	else
		return dbutil.execQuerys(sqldb.MySQLConPool, QRY_TO_EXEC, data, cntxtDtls);
};
// ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
exports.getweekdatawiseMdl = function (callback) {
	var cntxtDtls = "in  getweekdatawiseMdl";
	var QRY_TO_EXEC = `SELECT COUNT(*) as tcnt,DATE_FORMAT(date,"%d-%m-%Y") as currentdate FROM add_patients where  d_in=0  GROUP BY date(date) order by date desc limit 7`;

	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};


exports.getusersanalysisMdl = function (callback) {
	var cntxtDtls = "in  getusersanalysisMdl";
	var QRY_TO_EXEC = `select(select count(id) from add_patients where d_in='0') as tot_users, 
	(select count(id) from add_patients where d_in='0' and gender='Male') as male_users,
	(select count(id) from add_patients where d_in='0' and gender='Female') as female_users `;

	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			//(err);
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};

exports.toatlcntsordersMdl = function (callback) {
	var date = moment().utcOffset("+05:30").format("YYYY-MM-DD HH:mm:ss");
	var cntxtDtls = "in toatlcntsordersMdl";
	var QRY_TO_EXEC = `SELECT(select count(*) from add_patients where d_in='0') as total_orders, (select count(*) from add_patients where DATE(date)=CURRENT_DATE() and d_in='0') as current_orders, (SELECT COUNT(*) FROM add_patients WHERE d_in=0 AND DATE(date) >= (NOW() - INTERVAL 7 DAY) ORDER BY date DESC) as seven_amount, (SELECT COUNT(*) FROM add_patients WHERE d_in=0 AND DATE(date) >= (NOW() - INTERVAL 30 DAY) ORDER BY date DESC) as thirty_amount`

	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};

// exports.totalcountsMdl = function (callback) {
// 	var date = moment().utcOffset("+05:30").format("YYYY-MM-DD HH:mm:ss");
// 	var cntxtDtls = "in totalcountsMdl";
// 	var QRY_TO_EXEC = `SELECT p.*,DATE_FORMAT(p.order_date,"%d/%m/%Y") as dated,CASE
//     WHEN p.payment_type = 'COD' THEN 'Cash'
//     WHEN p.payment_type = 'Online' THEN 'Online'
//     ELSE 'None'
// END AS payment_mode  FROM order_dtl_t as p where p.d_in='0' order by p.id desc`;

// 	if (callback && typeof callback == "function") {
// 		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
// 			callback(err, results);
// 			return;
// 		});
// 	}
// 	else
// 		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
// };
exports.getdatewiseAnalysisMdl = function (callback) {
	var cntxtDtls = "in getdatewiseAnalysisMdl";
	var QRY_TO_EXEC = `SELECT count(*) as MAU,DAYNAME(date)  as network, DAYOFWEEK(date) FROM add_patients
    WHERE  d_in='0' AND DAYNAME(date) is not null group by DAYNAME(date)`;


	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};

exports.gettotalappointmentdataMdl = function (callback) {
	var cvrclrViewDtls = "in gettotalappointmentdataMdl";
	var QRY_TO_EXEC = `select s.*,DATE_FORMAT(s.date,"%d-%m-%Y") as date from add_patients as s  where s.d_in=0 order by s.id desc`;
	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cvrclrViewDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cvrclrViewDtls);
};
// exports.topfivecustomersMdl = function (callback) {
// 	var date = moment().utcOffset("+05:30").format("YYYY-MM-DD HH:mm:ss");
// 	var cntxtDtls = "in topfivecustomersMdl";
// 	var QRY_TO_EXEC = `SELECT count(o.id) as cnt,o.customer_id,c.user_name,c.usr_phone,c.profile_pic FROM order_dtl_t as o join customer_dtl_t as c on o.customer_id=c.id GROUP by o.customer_id order by cnt desc limit 5;`;

// 	if (callback && typeof callback == "function") {
// 		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
// 			callback(err, results);
// 			return;
// 		});
// 	}
// 	else
// 		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
// };
// exports.topfiveItemsMdl = function (callback) {
// 	var date = moment().utcOffset("+05:30").format("YYYY-MM-DD HH:mm:ss");
// 	var cntxtDtls = "in topfiveItemsMdl";
// 	var QRY_TO_EXEC = `SELECT count(o.id) as cnt,o.item_nm,o.item_img1 FROM order_items_dtl_t as o  GROUP by o.item_id order by cnt desc limit 5`;

// 	if (callback && typeof callback == "function") {
// 		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
// 			callback(err, results);
// 			return;
// 		});
// 	}
// 	else
// 		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
// };

// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// mis reports start
exports.getExpandDataMdl = function (callback) {
	var cntxtDtls = "in getExpandDataMdl";
	var QRY_TO_EXEC = `SELECT * from expand  WHERE  d_in = 0  order by id desc;`;
	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};
exports.addExpandMdl = function (expandData, callback) {
	var cntxtDtls = "in addExpandMdl";
	var dat = new Date();
	var date = dat.getDay - dat.getMonth - dat.getFullYear;
	var today = moment().format('YYYY-MM-DD');
	var QRY_TO_EXEC = ` insert into expand (username, userid, expandfor, expendtype, expandamount, remarks, date, user_id, cts)
	 values( '${expandData.name.username}', '${expandData.name.userid}', '${expandData.expandfor}',
		  '${expandData.expendtype}', '${expandData.expandamount}', '${expandData.remarks}', '${today}', '${expandData.user_id}', '${expandData.cts}') ; `
	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};
exports.getAccountMdl = function (callback) {
	var cntxtDtls = "in getAccountMdl";
	var date = new Date()
	var QRY_TO_EXEC = `SELECT (SELECT COALESCE(sum(grand_total),0) FROM order_dtl_t) as total, 
	(SELECT COALESCE(sum( grand_total), 0) FROM order_dtl_t WHERE DATE(order_date) = CURDATE() ) as today ,
	(SELECT COALESCE(sum(grand_total), 0) FROM order_dtl_t WHERE week(order_date) = week(now()) ) as weekly, 
	(SELECT COALESCE(sum(grand_total), 0) FROM order_dtl_t WHERE month(order_date) = month(curdate()) ) as monthly FROM order_dtl_t LIMIT 1;
	SELECT (SELECT COALESCE(sum(expandamount), 0) FROM expand WHERE d_in = 0) as total, 
	(SELECT COALESCE(sum(expandamount), 0) FROM expand WHERE DATE(date) = CURDATE() and d_in = 0) as today ,
	(SELECT COALESCE(sum(expandamount), 0) FROM expand WHERE week(date) = week(now()) and d_in = 0) as weekly, 
	(SELECT COALESCE(sum(expandamount), 0) FROM expand WHERE month(date) = month(curdate()) and d_in = 0) as monthly FROM expand LIMIT 1;  `;
	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};
exports.datewiseExpandMdl = function (ind, callback) {
	var cntxtDtls = "in datewiseExpandMdl";
	if (ind == 1) {
		var QRY_TO_EXEC = `SELECT sum(grand_total) as amount, order_date  as date  FROM order_dtl_t group by order_date  ;
        SELECT sum(expandamount) as expandamount, date  FROM expand group by date `;
	}
	if (ind == 0) {
		var QRY_TO_EXEC = `SELECT sum(grand_total) as amount, order_date  as date  FROM order_dtl_t WHERE DATE(order_date ) = CURDATE() group by order_date  ;
        SELECT sum(expandamount) as expandamount, date  FROM expand WHERE DATE(date) = CURDATE() group by date `;
	}
	if (ind == 2) {
		var QRY_TO_EXEC = `SELECT sum(grand_total) as amount, order_date  as date  FROM order_dtl_t  WHERE week(order_date ) = week(now()) group by order_date  ;
        SELECT sum(expandamount) as expandamount, date  FROM expand  WHERE week(date) = week(now()) group by date `;
	}
	if (ind == 3) {
		var QRY_TO_EXEC = `SELECT sum(grand_total) as amount, order_date  as date  FROM order_dtl_t  WHERE month(order_date ) = month(curdate()) group by order_date  ;
        SELECT sum(expandamount) as expandamount, date  FROM expand  WHERE month(date) = month(curdate()) group by date `;
	}
	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};
exports.getEnquiryMdl = function (callback) {
	var cntxtDtls = "in getEnquiryMdl";
	var QRY_TO_EXEC = `SELECT * from call_enquiry  WHERE  d_in = 0 order by id desc;`;
	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};
exports.addEnquiryMdl = function (enquirydata, callback) {
	var cntxtDtls = "in addEnquiryMdl";
	var QRY_TO_EXEC = ` insert into call_enquiry (name, number, remarks) values( '${enquirydata.name}', '${enquirydata.number}', '${enquirydata.remarks}') ; `;
	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};
exports.deleteEnquiryMdl = function (id, callback) {
	var cntxtDtls = "in deleteEnquiryMdl";
	var QRY_TO_EXEC = `update call_enquiry set d_in = 1  WHERE  id = '${id}' ;`;
	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};




exports.Add_type = function (data, callback) {
	var cntxtDtls = "in Add_type";
	var QRY_TO_EXEC = `Insert into roomtype_tbl(roomtype)values('${data.room_type}')`;
	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};

exports.getroomtype = function (callback) {
	var cntxtDtls = "in getroomtype";
	var QRY_TO_EXEC = `SELECT * from roomtype_tbl  WHERE  d_in = 0 order by id desc;`;
	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};

exports.updateroomtype = function (data, callback) {
	var cntxtDtls = "in updateroomtype";
	var QRY_TO_EXEC = `update  roomtype_tbl set roomtype = '${data.update_roomtype}' where id =  '${data.id}'   ; `
	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};

exports.deleteroomtype = function (data, callback) {
	var cntxtDtls = "in deleteroomtype";
	var QRY_TO_EXEC = `update roomtype_tbl set d_in=1 where id='${data.id}'`;
	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};

exports.Add_rooms = function (data, callback) {
	var cntxtDtls = "in Add_rooms";
	var QRY_TO_EXEC = `Insert into rooms_type(bed_type,room_number,price,description)values('${data.name}','${data.rooms}','${data.rooms_price}','${data.desc}')`;
	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};

exports.getrooms = function (callback) {
	var cntxtDtls = "in getrooms";
	var QRY_TO_EXEC = `SELECT * from rooms_type  WHERE  d_in = 0 order by id desc;`;
	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};

exports.editrooms = function (data, callback) {
	var cntxtDtls = "in editrooms";
	var QRY_TO_EXEC = `update  rooms_type set bed_type = '${data.update_roomtype}',room_number = '${data.rooms_update}',price = '${data.update_price}',description = '${data.update_desc}' where id =  '${data.id}'   ; `
	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};

exports.deleterooms = function (data, callback) {
	var cntxtDtls = "in deleterooms";
	var QRY_TO_EXEC = `update rooms_type set d_in=1 where id='${data.id}'`;
	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};

exports.Add_insurance = function (data, callback) {
	var cntxtDtls = "in Add_insurance";
	var QRY_TO_EXEC = `Insert into cashless_insurance(name)values('${data.name}')`;
	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};


exports.getinsurance = function (callback) {
	var cntxtDtls = "in getinsurance";
	var QRY_TO_EXEC = `SELECT * from cashless_insurance  WHERE  d_in = 0 order by id desc;`;
	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
}; 
exports.getPhonenumberMdl = function (callback) {
	var cntxtDtls = "in getPhonenumberMdl";
	var QRY_TO_EXEC = `select * from ss_appointments_tbl where d_in='0' and ind='1'`;
	console.log(QRY_TO_EXEC);
	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};

exports.editinsurance = function (data, callback) {
	var cntxtDtls = "in editinsurance";
	var QRY_TO_EXEC = `update  cashless_insurance set name = '${data.update_roomtype}' where id =  '${data.id}'; `

	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};

exports.deleteinsurance = function (data, callback) {
	var cntxtDtls = "in deleteinsurance";
	var QRY_TO_EXEC = `update cashless_insurance set d_in=1 where id='${data.id}'`;
	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};

exports.gethospitalroomsmdl = function (callback) {
	var cntxtDtls = "in gethospitalroomsmdl";
	var QRY_TO_EXEC = `select * from rooms_type where  d_in = 0 order by id desc `;
	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};
exports.getpatientsdata = function (callback) {
	var cntxtDtls = "in getpatientsdata";
	var QRY_TO_EXEC = `select * from add_patients where  d_in = 0 order by id desc `;
	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};


exports.admitpatient_room = function (idno, data, callback) {
	var cntxtDtls = "in admitpatient_room";
	var QRY_TO_EXEC = `Insert into admit_patients(uh_id,name,gender,phone_number,guardian,occupation,aadhar,address,complaint,doctor_name,age,med_claim,insurance_name,room_type,room_number,price,admin_date,amount,payment_types,transaction_id,ip_number)values('${data.uh_id}','${data.name}','${data.gender}','${data.phone_number}','${data.guardian}','${data.occupation}','${data.aadhar}','${data.address}','${data.complaint}','${data.doctor_name}','${data.age}','${data.med_claim}','${data.insurance_name}','${data.room_type}','${data.room_number}','${data.price}','${data.admin_date}','${data.amount}','${data.payment_types}','${data.transaction_id}','${idno}');Update rooms_type set room_status=1 where id ='${data.room_id}'`;
	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};



exports.checkTodayPatientCounts = function (data, callback) {
	var cntxtDtls = "in checkTodayPatientCounts";
	var QRY_TO_EXEC = `SELECT COUNT(DISTINCT ip_number) as new_patients_count FROM admit_patients WHERE DATE(admin_date) = CURRENT_DATE AND d_in = '0' `;
	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
}


// *************************************************** Add patient Start ********************************************************************




// *************************************************** Add patient Start ********************************************************************


exports.checkTodayPatientCount = function (data, callback) {
	var cntxtDtls = "in checkTodayPatientCount";
	var QRY_TO_EXEC = `SELECT COUNT(DISTINCT uh_id) as new_patients_count FROM add_patients WHERE DATE(date) = CURRENT_DATE AND patient_type = 'NEW'`;
	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
}




exports.addpatientmdl = function (idno, data, callback) {

	var cntxtDtls = "in addpatientmdl";

	var date = moment().utcOffset("+05:30").format("YYYY-MM-DD HH:mm:ss");
	

	var QRY_TO_EXEC = `INSERT INTO add_patients(appointment_type, patient_type, salutation,uh_id, sur_name, name,age, phone_number,guardian,
		occupation ,aadhar,address, complaint , gender, consultant_fee, days_to_expiry, date,description,blood_pressure,
		sugar,weight,height,others,
		doctor_department,doctor_name,expiry_date) VALUES ('${data.appointment_type}' , '${data.patient_type}' , '${data.salutation}','${idno}','${data.sur_name}',
		'${data.name}','${data.age}','${data.phone_number}','${data.guardian}', '${data.occupation}',
		 '${data.aadhar}','${data.address}', '${data.complaint}' ,
		'${data.gender}','${data.consultant_fee}','${data.days_to_expiry}','${date}','${data.description}','${data.blood_pressure}',
		'${data.sugar}','${data.weight}', '${data.height}' ,'${data.others}' ,'${data.dpt_name}' ,'${data.d_name}','${data.expiry_date}');`;

	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	} else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};

exports.getpatientsmdl = function (data, callback) {
	var cntxtDtls = "in getpatientsmdl";
	var QRY_TO_EXEC = `select * from add_patients where d_in = 0 order by id`;
	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};

exports.EditPatientmdl = function (data, callback) {
	var cntxtDtls = "in EditPatientmdl";
	var QRY_TO_EXEC = ` Update add_patients set sur_name ='${data.sur_name}',name ='${data.name}', age ='${data.age}',
	phone_number= '${data.phone_number}', occupation='${data.occupation}' ,
	 guardian='${data.guardian}',aadhar='${data.aadhar}',address='${data.address}',gender='${data.gender}'
	  where  id ='${data.patient_id}'`
	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	} else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};



exports.getDataAllpatientsmmdl = function (data, callback) {
	var cntxtDtls = "in getDataAllpatientsmmdl";
	var QRY_TO_EXEC = `select * from add_patients where d_in = 0 group by uh_id order by id`;
	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};



exports.checkCardRnwlforUhommdl = function (data, callback) {
	var cntxtDtls = "in checkCardRnwlforUhommdl";
	var QRY_TO_EXEC = `SELECT * FROM add_patients WHERE d_in = '0' AND uh_id = '${data.uh_id_no}' ORDER BY id DESC LIMIT 1;`;
	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};


exports.getbookingsrchdatamdl = function (data, callback) {

	var cntxtDtls = "in getbookingsrchdatamdl";
	var QRY_TO_EXEC = `SELECT * FROM add_patients where d_in='0' and  date(date) between '${data.from_date}' and '${data.to_date}'`;
	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};





exports.getbookingdatamdl = function (callback) {
	var cntxtDtls = "in getbookingdatamdl";
	var QRY_TO_EXEC = `SELECT * FROM add_patients WHERE d_in = '0'`;
	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else {
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
	}
};

//////////////////////////////////////////////////////////////////////////////////////////////////////// doctors

exports.getDoctorsDatammdl = function (data, callback) {
	var cntxtDtls = "in getDoctorsDatammdl";
	var QRY_TO_EXEC = `select * from add_doctor where d_in =0`;
	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};
exports.Add_doctormdl = function (data, callback) {
	var cntxtDtls = "in Add_doctormdl";
	var QRY_TO_EXEC = `INSERT INTO add_doctor(doctor_name,doctor_age,doctor_gender,doctor_number,doctor_address,
		license_number,doctor_timings,doctor_charges,doctor_dept,doctor_experience,
		doctor_email,description)values('${data.doctor_name}','${data.doctor_age}','${data.doctor_gender}','${data.doctor_number}',
		'${data.doctor_address}','${data.license_number}','${data.doctor_timings}','${data.doctor_charges}','${data.doctor_dept}',
		'${data.doctor_experience}','${data.doctor_email}' , '${data.description}');`
	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};

exports.getdepartmentmdl = function (data, callback) {
	var cntxtDtls = "in getdepartmentmdl";
	var QRY_TO_EXEC = `select * from  specialist_names where d_in =0`;
	if (callback && typeof callback == "function") {
		dbutil.execQuery(
			sqldb.MySQLConPool,
			QRY_TO_EXEC,
			cntxtDtls,
			function (err, results) {
				callback(err, results);
				return;
			}
		);
	} else return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};

exports.gettimingsmdl = function (data, callback) {
	var cntxtDtls = "in gettimingsmdl";
	var QRY_TO_EXEC = `select * from  doctor_timings where d_in =0`;
	if (callback && typeof callback == "function") {
		dbutil.execQuery(
			sqldb.MySQLConPool,
			QRY_TO_EXEC,
			cntxtDtls,
			function (err, results) {
				callback(err, results);
				return;
			}
		);
	} else return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};

exports.addNewdepartmentmdl = function (data, callback) {
	var cntxtDtls = "in addNewdepartmentmdl";
	var QRY_TO_EXEC = `Insert into specialist_names(name)values('${data.name}');`;
	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};


exports.addNewtimingsmdl = function (data, callback) {
	var cntxtDtls = "in addNewtimingsmdl";
	var QRY_TO_EXEC = `Insert into doctor_timings(timings)values('${data.name}');`;
	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};


// *************************************************** Add patient END ********************************************************************



//prasad 02052024//
exports.getappoinmentreportformMdl = function (callback) {
	var cvrclrViewDtls = "in getappoinmentreportformMdl";
	var QRY_TO_EXEC = `select s.* from ss_appointments_tbl as s  where s.d_in=0 order by s.date desc`;

	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cvrclrViewDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cvrclrViewDtls);
};

exports.getfromdatetodateMdl = function (fromdate, toDate, u_id, location, appointment, callback) {
	var cvrclrViewDtls = "in getfromdatetodateMdl";
	var QRY_TO_EXEC = `select s.* from ss_appointments_tbl as s  where s.d_in=0 and s.location ='${location}' and s.Date between'${fromdate}' and '${toDate}' and s.ind='${appointment}'`;
	console.log(QRY_TO_EXEC);
	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cvrclrViewDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cvrclrViewDtls);
};
exports.getlocationdropdownpageMdl = function (callback) {
	var cvrclrViewDtls = "in getlocationdropdownpageMdl";
	var QRY_TO_EXEC = `select * from ss_appointments_tbl where d_in=0`;
	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cvrclrViewDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cvrclrViewDtls);
};
exports.getpatientdropdowMdl = function (callback) {
	var cntxtDtls = "in getpatientdropdowMdl";
	var QRY_TO_EXEC = `SELECT name FROM ss_appointments_tbl WHERE d_in=0 group by name ;`;

	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};
exports.getphonedropdowMdl = function (callback) {

	var cntxtDtls = "in getphonedropdowMdl";
	var QRY_TO_EXEC = `SELECT phone_no FROM ss_appointments_tbl WHERE d_in=0 group by phone_no ;`;

	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};
exports.getPatient1Mdl = function (data, callback) {

	var facDtls = "in getPatient1Mdl";
	var name = '';

	if (data.name) {
		name = `AND name='${data.name}'`
	} else {
		name = '';
	}
	if (data.phone) {
		phone = `AND phone_no='${data.phone}'`
	} else {
		phone = '';
	}
	var QRY_TO_EXEC = `SELECT * FROM ss_appointments_tbl WHERE d_in=0 ${name} ${phone} order by id desc;`;

	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, facDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, facDtls);
};
exports.updatecontactdetailsformpageMdl = function (data, callback) {
	var cntxtDtls = "in updatecontactdetailsformpageMdl";
	var date = moment().utcOffset("+05:30").format('YYYY-MM-DD HH:mm:ss');
	var QRY_TO_EXEC = `UPDATE ss_contact_tbl SET name = '${data.name}', phone_no = '${data.phone_no}',email = '${data.email}',message = '${data.message}', i_ts = '${date}' WHERE id = ${data.id} `;
	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};
exports.deletecontactformMdl = function (id, callback) {
	var cntxtDtls = "in deletecontactformMdl";
	var date = moment().utcOffset("+05:30").format('YYYY-MM-DD HH:mm:ss');
	// 		var QRY_TO_EXEC = `UPDATE usr_dtl_t SET d_in =1,d_ts = '${date}' WHERE id = '${id}';`;
	var QRY_TO_EXEC = `UPDATE ss_contact_tbl SET d_in =1 WHERE id = '${id}';`;

	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};
exports.getcontactreportformformMdl = function (callback) {
	var cvrclrViewDtls = "in getcontactreportformformMdl";
	var QRY_TO_EXEC = `select * from ss_contact_tbl where d_in=0`;
	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cvrclrViewDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cvrclrViewDtls);
};
exports.getlocationdropdownformpagewiseMdl = function (callback) {
	var cvrclrViewDtls = "in getlocationdropdownformpagewiseMdl";
	var QRY_TO_EXEC = `select * from day_generat_ops`;
	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cvrclrViewDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cvrclrViewDtls);
};
exports.updatefromtotimedetailsformMdl = function (data, callback) {
	var cntxtDtls = "in updatefromtotimedetailsformMdl";
	var date = moment().utcOffset("+05:30").format('YYYY-MM-DD HH:mm:ss');
	var QRY_TO_EXEC = `UPDATE appointments SET fromtime = '${data.fromtime}', totime = '${data.totime}',no_of_appointments = '${data.no_of_appointments}', i_ts = '${date}' WHERE id = ${data.id} `;
	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};
exports.gettimetotalcheckdataMdl = function (callback) {
	var cvrclrViewDtls = "in gettimetotalcheckdataMdl";
	var QRY_TO_EXEC = `select * from appointments where d_in=0 order by id desc`;
	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cvrclrViewDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cvrclrViewDtls);
};
exports.checktimepagemdl = function (data, callback) {
	var cntxtDtls = "in checktimepagemdl";
	var QRY_TO_EXEC = `select id from appointments where fromtime = '${data.fromtime}' and totime='${data.totime}' and location='${data.location}' and date='${data.date}' and d_in='0';`

	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};
exports.postappointmentsformMdl = function (data, callback) {

	var cntxtDtls = "in postappointmentsformMdl";
	var i_ts = moment().utcOffset("+05:30").format("HH:mm:ss");
	var date = moment().utcOffset("+05:30").format('YYYY-MM-DD');
	var SUB_QRY_TO_EXEC = '';
	var QRY_TO_EXEC = ''
	for (var d = 0; d < data.dates.length; d++) {
		var SUB_QRY_TO_EXEC = `INSERT INTO appointments(date,fromtime,totime,no_of_appointments,location,doctor_name) VALUES ('${data.dates[d]}','${data.fromtime}','${data.totime}','${data.no_of_appointments}','${data.location}','${data.doctor_name}');`;
		QRY_TO_EXEC = QRY_TO_EXEC + SUB_QRY_TO_EXEC;
	}

	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};
exports.deletetimeslotspageformMdl = function (id, callback) {
	var cntxtDtls = "in deletetimeslotspageformMdl";
	var date = moment().utcOffset("+05:30").format('YYYY-MM-DD HH:mm:ss');
	// 		var QRY_TO_EXEC = `UPDATE usr_dtl_t SET d_in =1,d_ts = '${date}' WHERE id = '${id}';`;
	var QRY_TO_EXEC = `UPDATE appointments SET d_in =1 WHERE id = '${id}';`;

	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};
exports.getlocationdropdownpageMdl = function (callback) {
	var cvrclrViewDtls = "in getlocationdropdownpageMdl";
	var QRY_TO_EXEC = `select * from ss_appointments_tbl where d_in=0`;
	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cvrclrViewDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cvrclrViewDtls);
};
exports.getmonthreportdatamdl = function (data, callback) {

	var cntxtDtls = "in getmonthreportdatamdl";
	var cdate = moment().utcOffset("+05:30").format('YYYY-MM-DD');
	var date = new Date();
	date.setDate(date.getDate() - 30);
	var thirtyDays = date.toISOString().split('T')[0];
	var frecipedated = '';
	var trecipedated = '';
	var person_id = '';
	if (data.frecipedated) {

		frecipedated = ` AND c.date>='${data.frecipedated}'`
	} else {
		frecipedated = ` AND c.date>='${thirtyDays}'`
	}
	if (data.trecipedated) {
		trecipedated = ` AND c.date<='${data.trecipedated}'`
	} else {
		trecipedated = ` AND c.date<='${cdate}'`
	}
	if (data.location) {
		location = `  AND c.location='${data.location}'`
	} else {
		location = '';
	}
	var QRY_TO_EXEC = `SELECT * FROM  appointments as c where c.d_in='0' ${frecipedated} ${trecipedated} ${location} group by c.id order by c.date desc;`;
	// 	 
	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};
exports.deletemonthadatpageMdl = function (id, callback) {
	var cntxtDtls = "in deletemonthadatpageMdl";
	var date = moment().utcOffset("+05:30").format('YYYY-MM-DD HH:mm:ss');
	// 		var QRY_TO_EXEC = `UPDATE usr_dtl_t SET d_in =1,d_ts = '${date}' WHERE id = '${id}';`;
	var QRY_TO_EXEC = `UPDATE appointments SET d_in =1 WHERE id = '${id}';`;

	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};
exports.getmonthwiseformpageMdl = function (callback) {
	var cvrclrViewDtls = "in getmonthwiseformpageMdl";
	var QRY_TO_EXEC = `select * from appointments where d_in=0 order by id desc`;
	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cvrclrViewDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cvrclrViewDtls);
};
exports.getLastopId = function (callback) {
	var cvrclrViewDtls = "in getLastopId";
	var QRY_TO_EXEC = `SELECT op_idi FROM ss_appointments_tbl order by id desc limit 1;`;
	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cvrclrViewDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cvrclrViewDtls);
};
exports.submitofflinedatapageMdl = function (data, op_idi, op_number, callback) {

	var cntxtDtls = "in submitofflinedatapageMdl";
	var i_ts = moment().utcOffset("+05:30").format("HH:mm:ss");
	var i_ts = moment().utcOffset("+05:30").format("HH:mm:ss");

	var QRY_TO_EXEC = `INSERT INTO ss_appointments_tbl(op_idi,op_number,date,time,name,phone_no,age,gender,email,location,ind) VALUES('${op_idi}','${op_number}','${data.date}','${data.time}','${data.name}','${data.phone_no}','${data.age}','${data.gender}','${data.email}','${data.location}','2')`;

	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};
exports.getlocationdropofflineformpageMdl = function (callback) {
	var cvrclrViewDtls = "in getlocationdropofflineformpageMdl";
	var QRY_TO_EXEC = `select * from ss_appointments_tbl where d_in=0`;
	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cvrclrViewDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cvrclrViewDtls);
};
exports.postsubmitgallerypageMdl = function (data, UploadImage, callback) {
	var date = moment().utcOffset("+05:30").format("YYYY-MM-DD HH:mm:ss");
	var cntxtDtls = "in postsubmitgallerypageMdl";

	var QRY_TO_EXEC = `insert into imagegallery_table(image,port_folio)values('${UploadImage}','${data.port_folio}'); `;

	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};
exports.getgallerydataMdl = function (callback) {
	var cvrclrViewDtls = "in getgallerydataMdl";
	var QRY_TO_EXEC = `select * from imagegallery_table where d_in=0 order by id desc`;

	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cvrclrViewDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cvrclrViewDtls);
};
exports.modelgallaryimageeditmdl = function (data, imageupload, callback) {
	var cntxtDtls = "in modelgallaryimageeditmdl";
	var date = moment().utcOffset("+05:30").format('YYYY-MM-DD HH:mm:ss');
	var QRY_TO_EXEC = `UPDATE imagegallery_table SET image = '${imageupload}' WHERE  id='${data.id}' `;

	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};
exports.deleteimageMdl = function (id, callback) {
	var cntxtDtls = "in deleteimageMdl";
	var QRY_TO_EXEC = `update imagegallery_table set d_in=1 where id = ${id.id} ;`;

	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};


exports.checkoutpatient_roommdl = function (data, callback) {
	var cntxtDtls = "in checkoutpatient_roommdl";
	var QRY_TO_EXEC = `SELECT b.amount,b.room_number,b.admin_date,c.* FROM rooms_type as a join admit_patients as b on a.room_number = b.room_number join add_patients as c on b.uh_id = c.uh_id  where a.id='${data.id}'  and b.room_status=1 GROUP by c.uh_id;`
	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};
exports.checkoutpatientsubmitmdl = function (data, callback) {
	var cntxtDtls = "in checkoutpatientsubmitmdl";
	var QRY_TO_EXEC = `update admit_patients set discharge_amount = '${data.lessadvance}', discharge_date = '${data.discharge_date}', room_status= 2 where uh_id='${data.uh_id}';
	update rooms_type set room_status = 2 where room_number ='${data.room_number}' `

	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};
exports.availableroomtypemdl = function (data, callback) {
	var cntxtDtls = "in availableroomtypemdl";
	var QRY_TO_EXEC = ` update rooms_type set room_status = 0 where id='${data.id}' ; `
	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};
exports.checkinreports = function (data, callback) {
	var cntxtDtls = "in checkinreports";
	var QRY_TO_EXEC = `SELECT * from admit_patients where admin_date BETWEEN '${data.from_date}' AND '${data.to_date}' and d_in='0' and room_status = '1' ORDER BY id DESC`;

	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};

exports.checkoutreports = function (data, callback) {
	var cntxtDtls = "in checkoutreports";
	var QRY_TO_EXEC = `SELECT * from admit_patients where admin_date BETWEEN '${data.from_dates}' AND '${data.to_dates}' and d_in='0' and room_status = '2' ORDER BY id DESC`;

	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};






// *************************************************** Diagnostic Start  ********************************************************************

exports.adddiagnoTestmmdl = function (data, callback) {
	var cntxtDtls = "in adddiagnoTestmmdl";
	var QRY_TO_EXEC = `Insert into diagnostic_tests(d_test_date ,d_test_name , d_test_amount)values('${data.d_test_date}' ,'${data.d_test_name}' , '${data.d_test_amount}' );`;
	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};



exports.getdiagnosticTestsmmdl = function (data, callback) {
	var cntxtDtls = "in getdiagnosticTestsmmdl";
	var QRY_TO_EXEC = `select * from  diagnostic_tests where d_in =0`;
	if (callback && typeof callback == "function") {
		dbutil.execQuery(
			sqldb.MySQLConPool,
			QRY_TO_EXEC,
			cntxtDtls,
			function (err, results) {
				callback(err, results);
				return;
			}
		);
	} else return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};



exports.editdiagnoTestmmdl = function (data, callback) {
	var cntxtDtls = "in editdiagnoTestmmdl";
	var QRY_TO_EXEC = ` Update diagnostic_tests set d_test_date ='${data.d_test_date}',d_test_name ='${data.d_test_name}', d_test_amount ='${data.d_test_amount}'
	  where  id ='${data.id}'`
	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	} else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};





exports.dltdiagnoTestmmdl = function (data, callback) {
	var cntxtDtls = "in dltdiagnoTestmmdl";
	var QRY_TO_EXEC = ` Update diagnostic_tests set d_in='1' where  id ='${data.id}'`
	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	} else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};




exports.adddiagnoptntDtsmmdl = function (data, callback) {
	var cntxtDtls = "in adddiagnoptntDtsmmdl";

	var date = moment().utcOffset("+05:30").format("YYYY-MM-DD HH:mm:ss");

	var QRY_TO_EXEC = `insert into diagnostic_patient_details(	diagnostic_date ,uh_id,patient_type,
		sur_name,name,age,gender,address)values( '${date}' , '${data.patientsdts.uh_id}' , '${data.patientsdts.patient_type}' ,
		'${data.patientsdts.sur_name}' , '${data.patientsdts.name}' , '${data.patientsdts.age}' ,
		 '${data.patientsdts.gender}' , '${data.patientsdts.address}')`
	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	} else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};


exports.adddiagnoptntTstdtsmmdl = function (lastid, data, callback) {
	var cntxtDtls = "in adddiagnoptntTstdtsmmdl";

	var QRY_TO_EXEC = '';

	var uh_id_num = data.patientsdts.uh_id

	QRY_TO_EXEC = `INSERT INTO diagnostic_patient_test_details(diagnostic_patient_id,uh_id,	
		d_test_name,d_test_amount) VALUES ?`;

	const values = data.patientstestdts.map(obj => [lastid, uh_id_num, obj.d_test_name, obj.d_test_amount]);

	if (callback && typeof callback == "function")
		dbutil.sqlinjection(sqldb.MySQLConPool, QRY_TO_EXEC, values, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);

};




exports.getpatientsDetailsTestsmmdl = function (data, callback) {
	var cntxtDtls = "in getpatientsDetailsTestsmmdl";
	var QRY_TO_EXEC = `select * from diagnostic_patient_details where d_in='0'`
	// var QRY_TO_EXEC =``
	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	} else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};




exports.getpatientDiagnosticTestsmmdl = function (data, callback) {
	var cntxtDtls = "in getpatientDiagnosticTestsmmdl";
	var QRY_TO_EXEC = `select * from diagnostic_patient_test_details where d_in='0' and diagnostic_patient_id='${data.group_id}'`
	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	} else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};


// *************************************************** Diagnostic Start end   ********************************************************************




// *************************************************** Labs Start    ***********************************************************************************

exports.add_labtestmdl = function (data, callback) {
	var cntxtDtls = "in add_labtestmdl";
	var QRY_TO_EXEC = `Insert into all_lab_tests(amount,labtest)values('${data.data1.amount}','${data.data1.lab_type}')`;
	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};

exports.postLabFieldsmmdl = function (id, data, array, callback) {
	var cntxtDtls = "in postLabFieldsmmdl";
	var QRY_TO_EXEC = `insert into lab_tests_fields( labtest_id , field , ranges , units)values('${id}' ,
	              '${array.field_name}' , '${array.field_range}' , '${array.field_units}')`;
	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};

exports.get_labtestmdl = function (data, callback) {
	var cntxtDtls = "in get_labtestmdl";
	var QRY_TO_EXEC = `Select * from all_lab_tests where d_in=0`;
	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};

exports.delete_labtestmdl = function (data, callback) {
	var cntxtDtls = "in delete_labtestmdl";
	var QRY_TO_EXEC = `update all_lab_tests set d_in = 1 where id = '${data.id}';`;
	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};


exports.editlabDetailsmdl = function (data, callback) {
	var cntxtDtls = "in editlabDetailsmdl";
	var QRY_TO_EXEC = `update all_lab_tests set labtest='${data.labtest}' , amount='${data.amount}'  where id='${data.id}'`;
	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};



exports.getlabtestFieldsmmdl = function (data, callback) {
	var cntxtDtls = "in getlabtestFieldsmmdl";
	var QRY_TO_EXEC = `select * from lab_tests_fields where d_in='0' and labtest_id='${data.group_id}'`
	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	} else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};





exports.addassign_medicaltestsmdl = function (data, callback) {
	var cntxtDtls = "in addassign_medicaltestsmdl";
	var date = moment().utcOffset("+05:30").format("YYYY-MM-DD HH:mm:ss");
	var QRY_TO_EXEC = `Insert into labtest_assigned_patients(uh_id,name , age ,number ,grandtotal,date,payment_mode,transaction_id)values('${data.form.uh_id}', '${data.form.name}' ,'${data.form.age}'  ,'${data.form.number}' , '${data.form.grandtotal}', '${date}','${data.form.payment_mode}','${data.form.transaction_id}')`;
	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};


exports.assignedmedicltests = function (lastid, data, callback) {
	var QRY_TO_EXEC = ""
	var MUL_QRY_TO_EXEC = ""
	var cntxtDtls = "in assignedmedicltests";
	for (i = 0; i < data.medicallistArr.length; i++) {
		QRY_TO_EXEC = `INSERT INTO patients_labtests_details(labtest_patient_id,labtest_id,labtest_name,amount)VALUES('${lastid}','${data.medicallistArr[i].labtest_id}','${data.medicallistArr[i].labtest}','${data.medicallistArr[i].amount}'); `
		MUL_QRY_TO_EXEC = MUL_QRY_TO_EXEC + QRY_TO_EXEC;
	}
	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, MUL_QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, MUL_QRY_TO_EXEC, cntxtDtls);
};




exports.getlabreportsnum = function (data, callback) {
	var cntxtDtls = "in getlabreportsnum";

	var QRY_TO_EXEC = `select * from labtest_assigned_patients where d_in=0 and test_status<>'true';`

	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};

exports.getlabtestnames = function (data, callback) {
	var cntxtDtls = "in getlabtestnames";
	var QRY_TO_EXEC = `SELECT a.labtest_id,a.labtest_name, a.amount ,c.field,c.ranges,c.units FROM patients_labtests_details 
	as a join all_lab_tests as b
	 on a.labtest_id = b.id join lab_tests_fields as c on b.id = c.labtest_id where a.labtest_patient_id = '${data.id}' and a.d_in=0;`
	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};



exports.PostTestsDoneDataMmdl = function (	patient_group_tests_id, details, eachTest, callback) {
	var cntxtDtls = "in PostTestsDoneDataMmdl";
	var QRY_TO_EXEC = ""
	var MUL_QRY_TO_EXEC = ""
	var date = moment().utcOffset("+05:30").format("YYYY-MM-DD HH:mm");

	for (var i = 0; i < eachTest.length; i++) {
		QRY_TO_EXEC = `insert into completed_lab_tests( 	patient_group_tests_id ,uh_id , name , age , number ,labtest_id , labtest_name , amount , field , ranges , units , value , date)
		VALUES( '${patient_group_tests_id}' ,'${details.uh_id}' , '${details.name}' , '${details.age}' , '${details.number}' ,'${eachTest[i].labtest_id}',
		'${eachTest[i].labtest_name}','${eachTest[i].amount}' ,'${eachTest[i].field}','${eachTest[i].ranges}','${eachTest[i].units}','${eachTest[i].value}' , '${date}');`
		MUL_QRY_TO_EXEC = MUL_QRY_TO_EXEC + QRY_TO_EXEC;
	}
	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, MUL_QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, MUL_QRY_TO_EXEC, cntxtDtls);
};

exports.setLabTestDonemmdl = function (id, callback) {
	var cntxtDtls = "in setLabTestDonemmdl";
	var date = moment().utcOffset("+05:30").format("YYYY-MM-DD HH:mm");
	var QRY_TO_EXEC = `update labtest_assigned_patients set completed_date='${date}', test_status='true' where id='${id}'`;
	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};


exports.getmedicalreportsmdl = function (data, callback) {
	var cntxtDtls = "in getmedicalreportsmdl";

	var QRY_TO_EXEC = `select * , grandtotal as amount from labtest_assigned_patients where 
	  test_status='true' and d_in='0' order by id desc;`

	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};


exports.getparticularlabdetialsmdl = function (data, callback) {
	var cntxtDtls = "in getparticularlabdetialsmdl";
	var QRY_TO_EXEC = `SELECT b.* FROM labtest_assigned_patients as a join patients_labtests_details as 
	b on a.id = b.labtest_patient_id where b.labtest_patient_id='${data.id}'`;
	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};



exports.getLabResultsEachmmdl = function (data, callback) {
	var cntxtDtls = "in getLabResultsEachmmdl";

	var QRY_TO_EXEC = `SELECT * FROM  completed_lab_tests  
  WHERE  uh_id='${data.uh_id}' and patient_group_tests_id='${data.id}' ORDER by labtest_id;`;


	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};

exports.editlabdatamdl = function (data, callback) {
	var cntxtDtls = "in editlabdatamdl";
	var QRY_TO_EXEC = `update  labtest_assigned_patients set name='${data.name}' , number='${data.number}' ,age='${data.age}',transaction_id = '${data.transaction_id}'  where id='${data.id}';`
	if (callback && typeof callback == "function") {
	  dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
		callback(err, results);
		return;
	  });
	}
	else
	  return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
  };
  
  exports.mainGetforAssignLabsmdl = function (data, callback) {
	var cntxtDtls = "in mainGetforAssignLabsmdl";
	var QRY_TO_EXEC = `select * from labtest_assigned_patients where d_in = 0 order by id;`
	if (callback && typeof callback == "function") {
	  dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
		callback(err, results);
		return;
	  });
	}
	else
	  return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
  };
  
  exports.getlabTestsmdl = function (data, callback) {
	var cntxtDtls = "in getlabTestsmdl";
	var QRY_TO_EXEC = `select * from patients_labtests_details where d_in='0' and labtest_patient_id='${data.group_id}'`
  
	if (callback && typeof callback == "function") {
	  dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
		callback(err, results);
		return;
	  });
	} else
	  return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
  };





// *************************************************** Labs  End   ******************************************************************** 



exports.pharmaitemsaddMdl = function (data, callback) {
	var cntxtDtls = "in pharmaitemsaddMdl";
	var QRY_TO_EXEC = `insert into pharmcy_items(medicine_name)values('${data.medicine_name}'); `;

	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};
exports.getmedicinenameMdl = function (callback) {
	var cvrclrViewDtls = "in getmedicinenameMdl";
	var QRY_TO_EXEC = `select * from pharmcy_items where d_in=0 order by id desc`;

	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cvrclrViewDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cvrclrViewDtls);
};
exports.supplieradddataMdl = function (data, callback) {
	var cntxtDtls = "in supplieradddataMdl";

	var QRY_TO_EXEC = `insert into pharmacy_suppliers(supplier_name,supplier_number,gst_number)values('${data.supplier_name}','${data.supplier_number}','${data.supplier_gst}'); `;

	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};
exports.getsupplierdataMdl = function (callback) {
	var cvrclrViewDtls = "in getsupplierdataMdl";
	var QRY_TO_EXEC = `select * from pharmacy_suppliers where d_in=0 order by id desc`;

	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cvrclrViewDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cvrclrViewDtls);
};
exports.getmedicinetypesMdl = function (callback) {
	var cvrclrViewDtls = "in getmedicinetypesMdl";
	var QRY_TO_EXEC = `select * from pharmacy_types where d_in=0 order by id desc`;

	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cvrclrViewDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cvrclrViewDtls);
};

exports.todaycheckindata = function (callback) {
	var cvrclrViewDtls = "in todaycheckindata";
	var QRY_TO_EXEC = `select * from admit_patients where DATE(admin_date)=CURRENT_DATE() and d_in='0' and room_status = '1' order by id desc`;
	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cvrclrViewDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cvrclrViewDtls);
};

exports.todaycheckoutdata = function (callback) {
	var cvrclrViewDtls = "in todaycheckoutdata";
	var QRY_TO_EXEC = `select * from admit_patients where DATE(discharge_date)=CURRENT_DATE() and d_in='0' and room_status = '2' order by id desc`;
	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cvrclrViewDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cvrclrViewDtls);
};

exports.gettodayaccountmdl = function (data, callback) {
	var cvrclrViewDtls = "in gettodayaccountmdl";
	var date = moment().utcOffset("+05:30").format("YYYY-MM-DD");
	var QRY_TO_EXEC = `select sum(amount) as todayroomamount from admit_patients where date(admin_date)=CURRENT_DATE()  ;
	select sum(consultant_fee) as todayopamount from add_patients where date(date)=CURRENT_DATE();`
	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cvrclrViewDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cvrclrViewDtls);
};

exports.getDatewiseamountmdl = function (data, callback) {
	var cvrclrViewDtls = "in getDatewiseamountmdl";
	var QRY_TO_EXEC = `select sum(amount) as todayroomamount from admit_patients where admin_date between'${data.from}' and '${data.to}';
                       select sum(consultant_fee) as todayopamount from add_patients where date between'${data.from}' and '${data.to}'`;
	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cvrclrViewDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cvrclrViewDtls);
};
//***********************************op-patients(insurance)*************************/ 
// select * from ss_appointments_tbl where DATE(date)=CURRENT_DATE() and d_in='0' and ind ='1' order by id desc;


exports.addInsurancemdl = function (data, callback) {
	var cvrclrViewDtls = "in addInsurancemdl";
	var QRY_TO_EXEC = `insert into insurance(insurance_type) values('${data.insurance_type}')`;

	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cvrclrViewDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cvrclrViewDtls);
};
exports.getInsurancemdl = function (callback) {
	var cvrclrViewDtls = "in getInsurancemdl";
	var QRY_TO_EXEC = `select * from  insurance  where d_in=0 `;
	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cvrclrViewDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cvrclrViewDtls);
};

exports.getappoinmentreportform1Mdl = function (callback) {
	var cvrclrViewDtls = "in getappoinmentreportform1Mdl";
	var QRY_TO_EXEC = `select s.* from ss_appointments_tbl as s  where s.d_in=0   and s.ind='1' `;

	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cvrclrViewDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cvrclrViewDtls);
};


exports.getsstimeslotsDataMdl1 = function (date,loc, callback) {
     if (loc == "అత్తిలి") {
         loc = "Attili";
    }else if(loc == "రాజమండ్రి") {
        loc = "Rajahmundry";
    }else if(loc == "పాలకొల్లు")
    {
        loc = "Palakollu";
    }else if(loc == "తణుకు")
    {
        loc = "Tanuku";
    }
	var cntxtDtls = "in getsstimeslotsDataMdl1";
	var ctime = moment().utcOffset("+05:30").format("HH:mm");
	console.log(ctime);
	var today_date = moment().utcOffset("+05:30").format("YYYY-MM-DD");
// 	if(today_date==date) {
// 		var timecheck = ` and system_time > "${ctime}"`;
// 	} else {
// 		var timecheck='';
// 	}
    var split_date = date.split('-');
    var dated = split_date[2] + '-' + split_date[1] + '-' + split_date[0];
	var QRY_TO_EXEC = `SELECT CONCAT(fromtime,' ', 'to',' ', totime) as title FROM  appointments where location='${loc}' and date='${dated}' and no_of_appointments != assigned_apptmts and d_in='0';`;
	console.log("heyy",QRY_TO_EXEC);
	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};



exports.getdoctornameMdl1 = function (date,loc, callback) {
     if (loc == "అత్తిలి") {
         loc = "Attili";
    }else if(loc == "రాజమండ్రి") {
        loc = "Rajahmundry";
    }else if(loc == "పాలకొల్లు")
    {
        loc = "Palakollu";
    }else if(loc == "తణుకు")
    {
        loc = "Tanuku";
    }
	var cntxtDtls = "in getdoctornameMdl1";
	var ctime = moment().utcOffset("+05:30").format("HH:mm");
	console.log(ctime);
	var today_date = moment().utcOffset("+05:30").format("YYYY-MM-DD");
    var split_date = date.split('-');
    var dated = split_date[2] + '-' + split_date[1] + '-' + split_date[0];
	var QRY_TO_EXEC = `SELECT doctor_name FROM  appointments where location='${loc}' and date='${dated}' and no_of_appointments != assigned_apptmts and d_in='0';`;
	console.log("heyy",QRY_TO_EXEC);
	if (callback && typeof callback == "function")
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};
//dates dynamic wati

exports.getLastopId = function (dated,callback) {
  var cvrclrViewDtls = "in getLastopId";
  
//   var dated = moment().utcOffset("+05:30").format("YYYY-MM-DD");
  
  var QRY_TO_EXEC = `SELECT op_idi FROM ss_appointments_tbl where date='${dated}' order by id desc limit 1;`;
  
  if (callback && typeof callback == "function")
    dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cvrclrViewDtls, function (err, results) {
      callback(err, results);
      return;
    });
  else
    return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cvrclrViewDtls);
};

exports.ssappointmentsDataMdl = function (data,op_idi,op_number, callback) {
	var cntxtDtls = "in ssappointmentsDataMdl";
	if(data.wati_ind == "1")
	{
	    	var tabName = data.cdate.split('-');
        	var dated = tabName[2] + "-" + tabName[1] + "-" + tabName[0];
        	var ind = '1'
        	var phone_no = data.phone_no.slice(2, 12);
	}else
	{
	    var dated = data.cdate;
	    var ind= '0';
	    var phone_no = data.phone_no.slice(2, 12);
	}
    if (data.location == "అత్తిలి") {
        data.location = "Attili";
    }
    else if(data.location == "రాజమండ్రి") {
        data.location = "Rajahmundry";
    }
    else if(data.location == "పాలకొల్లు")
    {
        data.location = "Palakollu";
    }
    else if(data.location == "తణుకు")
    {
        data.location = "Tanuku";
    }
    if (data.gender == "పురుషుడు") {
        data.gender = "Male";
    }
    else if(data.gender == "స్త్రీ") {
        data.gender = "Female";
    }
	var today_date = moment().utcOffset("+05:30").format("YYYY-MM-DD HH:mm:ss");
	var QRY_TO_EXEC = `insert into ss_appointments_tbl (op_idi,op_number,name,phone_no,age,gender,email,date,time,location,i_ts,ind)
    values('${op_idi}','${op_number}','${data.name}','${phone_no}','${data.age}','${data.gender}','${data.email}','${dated}','${data.time}','${data.location}','${today_date}','${ind}') `;
	console.log(QRY_TO_EXEC);
	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	} else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};


exports.getssapointmentvalueMdl = function (data, callback) {
	var cntxtDtls = "in getssapointmentvalueMdl";
	 if (data.location == "అత్తిలి") {
         data.location = "Attili";
    }
    else if(data.location == "రాజమండ్రి") {
        data.location = "Rajahmundry";
    }
    else if(data.location == "పాలకొల్లు")
    {
        data.location = "Palakollu";
    }
    else if(data.location == "తణుకు")
    {
        data.location = "Tanuku";
    }
    if(data.wati_ind == "1")
	{
	    	var tabName = data.cdate.split('-');
        	var dated = tabName[2] + "-" + tabName[1] + "-" + tabName[0];
	}else
	{
	    var dated = data.cdate;
	}
	var QRY_TO_EXEC = `update appointments set assigned_apptmts =  assigned_apptmts + 1 where date='${dated}' and location='${data.location}';`;
	console.log(QRY_TO_EXEC);
	if (callback && typeof callback == "function") {
		dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls, function (err, results) {
			callback(err, results);
			return;
		});
	}
	else
		return dbutil.execQuery(sqldb.MySQLConPool, QRY_TO_EXEC, cntxtDtls);
};





























