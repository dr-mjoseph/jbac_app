var express = require('express');
router = express.Router();
// var jwt = require('jsonwebtoken');
var sampleRoutes = require('../controllers/mainCtrl');
process.env.SECRET_KEY = "thisismysecretkey";

router.post('/getdashotp', sampleRoutes.getdashotpCtrl);
router.post('/getUserData', sampleRoutes.getUserDataCtrl);
router.get('/deleteUsers/:ind', sampleRoutes.deleteUsersCtrl);
router.post('/userlogindata', sampleRoutes.userlogindataCtrl);
router.post('/updateuserlogindata', sampleRoutes.updateuserlogindataCtrl);
router.post('/addUsers', sampleRoutes.addUsersCtrl);
router.get('/globalGet/:tablename', sampleRoutes.globalGeCtrl);
router.post('/getUserDatapass', sampleRoutes.getUserDatapassCtrl);
//permissions
router.get('/getUserPermissions', sampleRoutes.getUserPermissionsCtrl);
router.get('/getModules/:id', sampleRoutes.getModulesCtrl);
router.post('/submitpermissions', sampleRoutes.submitpermissionsCtrl);
router.post('/deletePermissions', sampleRoutes.deletePermissionsCtrl);
// user permission start
router.get('/getmodulelistdetails/:usr_id', sampleRoutes.getmodulelistdetailsCtrl);
router.get('/userpermissiongetdata', sampleRoutes.userpermissiondatactrl);
router.get('/getemployeelistdata', sampleRoutes.getemployeelistdataCtrl);
router.post('/postusermenulist', sampleRoutes.postusermenulistCtrl);
// user permission end


// //Analysis
router.get('/getweekdatawise', sampleRoutes.getweekdatawiseCtrl);
router.get('/getusersanalysisData', sampleRoutes.getusersanalysisCtrl);
router.get('/toatlcntsordersData', sampleRoutes.toatlcntsordersCtrl);
// router.get('/totalcountsData', sampleRoutes.totalcountsCtrl);
router.get('/getdatewiseAnalysisData', sampleRoutes.getdatewiseAnalysisCtrl);
router.get('/gettotalappointmentdata', sampleRoutes.gettotalappointmentdataCtrl);
// router.get('/topfivecustomersData', sampleRoutes.topfivecustomersCtrl);
// router.get('/topfiveItemsData', sampleRoutes.topfiveItemsCtrl);

// mis reports start
router.get('/getExpandData', sampleRoutes.getExpandDataCtrl);
router.post('/addExpand', sampleRoutes.addExpandCtrl);
router.get('/getAccount', sampleRoutes.getAccountCtrl);
router.get('/datewiseExpand/:ind', sampleRoutes.datewiseExpandCtrl);
router.get('/getEnquiry', sampleRoutes.getEnquiryCtrl);
router.post('/addEnquiry', sampleRoutes.addEnquiryCtrl);
router.get('/deleteEnquiry/:id', sampleRoutes.deleteEnquiryCtrl);

// *************************************************** Add patient Start ********************************************************************

router.post('/addpatient', sampleRoutes.addpatientctrl);
router.post('/getpatients', sampleRoutes.getpatientsctrl);
router.post('/EditPatient', sampleRoutes.EditPatientctrl);
router.post('/getDataAllpatients', sampleRoutes.getDataAllpatientsCtrl);
router.post('/checkCardRnwlforUho', sampleRoutes.checkCardRnwlforUhoCtrl);
router.post("/getbookingsrchdata", sampleRoutes.getbookingsrchdatactrl);
router.post("/getbookingdata", sampleRoutes.getbookingdatactrl);


router.post('/getDoctorsData', sampleRoutes.getDoctorsDataCtrl);
router.post('/Add_doctor', sampleRoutes.Add_doctorctrl);
router.post("/getdepartment", sampleRoutes.getdepartmentctrl);
router.post("/gettimings", sampleRoutes.gettimingsctrl);
router.post('/addNewdepartment', sampleRoutes.addNewdepartmentCtrl);
router.post('/addNewtimings', sampleRoutes.addNewtimingsCtrl);


// ********************************************************************


//prasad 02052024//
router.get('/getappoinmentreportform', sampleRoutes.getappoinmentreportformCtrl);
router.get('/getfromdatetodate/:fromdate/:toDate/:location/:u_id/:appointment', sampleRoutes.getfromdatetodatectrl);
router.get('/getlocationdropdown', sampleRoutes.getlocationdropdownCtrl);
router.post('/getpatientdropdow/', sampleRoutes.getpatientdropdowCtrl);
router.post('/getphonedropdow/', sampleRoutes.getphonedropdowCtrl);
router.post('/getPatient1', sampleRoutes.getPatient1Ctrl);
router.post('/updatecontactdetailsform', sampleRoutes.updatecontactdetailsformCtrl);
router.get('/deletecontactform/:id', sampleRoutes.deletecontactformCtrl);
router.get('/getcontactreportformform', sampleRoutes.getcontactreportformformCtrl);
router.get('/getlocationdropdownformpage', sampleRoutes.getlocationdropdownformpageCtrl);

router.post('/updatefromtotimedetails', sampleRoutes.updatefromtotimedetailsCtrl);
router.get('/gettimetotalcheck', sampleRoutes.gettimetotalcheckCtrl);
router.post('/checktime', sampleRoutes.checktimectrl);
router.post('/postappointments', sampleRoutes.postappointmentsctrl);
router.get('/deletetimeslotspage/:id', sampleRoutes.deletetimeslotspageCtrl);
router.get('/getlocationdropdown', sampleRoutes.getlocationdropdownCtrl);
router.post('/getmonthreportdata', sampleRoutes.getmonthreportdatactrl);
router.get('/getfrommonth', sampleRoutes.getfrommonthCtrl);
router.get('/deletemonthadat/:id', sampleRoutes.deletemonthadatCtrl);
router.get('/getmonthwiseform', sampleRoutes.getmonthwiseformCtrl);
router.post('/submitofflinedata', sampleRoutes.submitofflinedatactrl);
router.get('/getlocationdropofflineform', sampleRoutes.getlocationdropofflineformCtrl);
router.post('/postsubmitgallery', sampleRoutes.postsubmitgalleryCtrl);
router.get('/getgallerydata', sampleRoutes.getgallerydataCtrl);
router.post('/modelgallaryimageedit', sampleRoutes.modelgallaryimageeditctrl);
router.get('/deleteimage/:id', sampleRoutes.deleteimageCtrl);



// *************************************************** Add patient Start END *******************************************************************
/////////////////////////////////////////////add type/////////////////////////////////
router.post('/Add_type', sampleRoutes.Add_type);
router.get('/getroomtype', sampleRoutes.getroomtype);
router.post('/updateroomtype', sampleRoutes.updateroomtype);
router.post('/deleteroomtype', sampleRoutes.deleteroomtype);
/////////////////////////////////////////add rooms//////////////////////////////////////
router.post('/Add_rooms', sampleRoutes.Add_rooms);
router.get('/getrooms', sampleRoutes.getrooms);
router.post('/editrooms', sampleRoutes.editrooms);
router.post('/deleterooms', sampleRoutes.deleterooms);
///////////////////////////////////////////insurance///////////////////////////
router.post('/Add_insurance', sampleRoutes.Add_insurance);
router.get('/getinsurance', sampleRoutes.getinsurance);

router.post('/editinsurance', sampleRoutes.editinsurance);
router.post('/deleteinsurance', sampleRoutes.deleteinsurance);

///////////////////////////////////////////Rooms///////////////////////////
router.get('/gethospitalrooms', sampleRoutes.gethospitalroomsctrl);
router.get('/getpatientsdata', sampleRoutes.getpatientsdata);
router.post('/admitpatient_room', sampleRoutes.admitpatient_room);
router.post('/checkoutpatient_room', sampleRoutes.checkoutpatient_roomctrl);
router.post('/checkoutpatientsubmit', sampleRoutes.checkoutpatientsubmitctrl);
router.post('/availableroomtype', sampleRoutes.availableroomtypectrl);
router.post('/checkinreports', sampleRoutes.checkinreports);
router.post('/checkoutreports', sampleRoutes.checkoutreports);

// *************************************************** Diagnostic Start  ********************************************************************
router.post('/adddiagnoTest', sampleRoutes.adddiagnoTestCtrl);
router.post('/getdiagnosticTests', sampleRoutes.getdiagnosticTestsCtrl);
router.post('/editdiagnoTest', sampleRoutes.editdiagnoTestCtrl);
router.post('/dltdiagnoTest', sampleRoutes.dltdiagnoTestCtrl);
router.post('/addpatientDetailsTests', sampleRoutes.addpatientDetailsTestsCtrl);
router.post('/getpatientsDetailsTests', sampleRoutes.getpatientsDetailsTestsCtrl);
router.post('/getpatientDiagnosticTests', sampleRoutes.getpatientDiagnosticTestsCtrl);
// *************************************************** Diagnostic Start  end  ********************************************************************


// ************************************************************** labs  start ******************************************
router.post('/add_labtest', sampleRoutes.add_labtestctrl);
router.post('/get_labtest', sampleRoutes.get_labtestctrl);
router.post('/delete_labtest', sampleRoutes.delete_labtestctrl);
router.post('/editlabDetails', sampleRoutes.editlabDetailsCtrl);
router.post('/getlabtestFields', sampleRoutes.getlabtestFieldsCtrl);
router.post('/addassign_medicaltests', sampleRoutes.addassign_medicaltestsctrl);
router.post('/getlabreportsnum', sampleRoutes.getlabreportsnum);
router.post('/getlabtestnames', sampleRoutes.getlabtestnames);
router.post('/postTestsDoneData', sampleRoutes.PostTestsDoneDataCtrl);
router.post('/getmedicalreports', sampleRoutes.getmedicalreportsctrl);
router.post('/getparticularlabdetials', sampleRoutes.getparticularlabdetialsctrl);
router.post('/getLabResultsEach', sampleRoutes.getLabResultsEachCtrl);
router.post('/editlabdata', sampleRoutes.editlabdatactrl);
router.post('/mainGetforAssignLabs', sampleRoutes.mainGetforAssignLabsctrl);
router.post('/getlabTests', sampleRoutes.getlabTestsctrl);



// ************************************************************** labs  start  end  ********************************


router.post('/pharmaitemsadd', sampleRoutes.pharmaitemsaddCtrl);
router.get('/getmedicinename', sampleRoutes.getmedicinenameCtrl);
//06052024//
router.post('/supplieradddata', sampleRoutes.supplieradddataCtrl);
router.get('/getsupplierdata', sampleRoutes.getsupplierdataCtrl);
router.get('/getmedicinetypes', sampleRoutes.getmedicinetypesCtrl);
//////////////////////////////////////07-05-2024//////////////
router.get('/todaycheckindata', sampleRoutes.todaycheckindata);
router.get('/todaycheckoutdata', sampleRoutes.todaycheckoutdata);
router.post('/gettodayaccount', sampleRoutes.gettodayaccountCtrl);
router.post('/getDatewiseamount', sampleRoutes.getDatewiseamountCtrl);

//***********************************op-patients(insurance)*************************/
router.post('/addInsurance', sampleRoutes.addInsuranceCtrl);
router.post('/getInsurance', sampleRoutes.getInsuranceCtrl);
router.post('/getPhonenumber', sampleRoutes.getPhonenumberCtrl);
router.post('/getappoinmentreportform', sampleRoutes.getappoinmentreportform1Ctrl);
// getappoinmentreportform
//prasad added on 18-05-2024//
router.get('/getsstimeslotsData1/:date/:loc/:phno', sampleRoutes.getsstimeslotsDataCtrl1);
router.post('/ssappointmentsData', sampleRoutes.ssappointmentsDataCtrl);
module.exports = router;
