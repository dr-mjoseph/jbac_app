var mysql = require('mysql');
var MySQLConPool	= {};
// var USER = 'root',
//     PWD = '',
//     DATABASE = 'entnew2022_shanthi_ent_hospitals',
//     DB_HOST_NAME = 'localhost';

 var USER = 'entnew2022_shanthi_ent';
 var PWD = 'Aneel@6633';
 var DATABASE = 'entnew2022_shanthi_ent_hospitals';
 var DB_HOST_NAME = 'localhost';






var MAX_POOL_SIZE		= 10000;
var MIN_POOL_SIZE		= 50;



var MySQLConPool = mysql.createPool({
    host                : DB_HOST_NAME,
    port      		    : 3306,
    user                : USER,
    password            : PWD,
    database            : DATABASE,
    connectTimeout		: 20000,
    connectionLimit	    : MAX_POOL_SIZE,
    debug 		        : false,
    multipleStatements  : true,
    waitForConnections  : true
});




exports.MySQLConPool = MySQLConPool;