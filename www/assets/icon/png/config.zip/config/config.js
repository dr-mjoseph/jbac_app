// config.js
module.exports = {
    'secret': 'amvt-tms-temple-2024'
  };