var express = require('express');
var app = express();
var htt = express();
var expressValidator = require('express-validator');
util = require('util');
// SSl
const fs = require("fs");
const https = require("https");
// validations
app.use(expressValidator({
  errorFormatter: function (param, msg, value) {
    var namespace = param.split('.')
      , root = namespace.shift()
      , formParam = root;

    while (namespace.length) {
      formParam += '[' + namespace.shift() + ']';
    }
    return {
      fld_nm: formParam,
      msg_tx: msg,
      spld_vl: value
    };
  }
}));
// validations
// path = require('path');
appRoot = __dirname;

app.use(express.json({ limit: '10mb' }));

// Increase the limit for form data requests
app.use(express.urlencoded({ limit: '10mb', extended: true }));


app.use(function (req, res, next) {
  // Website you wish to allow to connect
  res.setHeader('Access-Control-Allow-Origin', '*');
  // Request methods you wish to allow
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
  // Request headers you wish to allow
  res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type,token');
  // Set to true if you need the website to include cookies in the requests sent
  // to the API (e.g. in case you use sessions)
  res.setHeader('Access-Control-Allow-Credentials', true);
  // Pass to next layer of middleware
  next();
});
app.use(logErrors);
app.use('/dashboardapi', require('./dashboard/routes/routes'));

function logErrors(err, req, res, next) {
  console.error(err.stack);
  next(err);
}

app.get('/', function (req, res) {
  res.send("TMS API Listining");
});

// var server = app.listen(6010, function () {
//   var host = server.address().address;
//   var port = server.address().port;

// });
// var server = app.listen(3200, function () {
//   var host = server.address().address;
//   var port = server.address().port;
//   console.log('pardha saradhi server http://%s:%s', host, port);
// });

https.createServer({
  key: fs.readFileSync('./privatekey.pem'),
  cert: fs.readFileSync('./cert.crt'),
  passphrase: '123456'
}, app)
.listen(3200);
console.log('Sri Santhi ENT Hospital is listening at https://::3200');






